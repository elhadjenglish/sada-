# Sada Stage 0: native wake-word test (Android)

A small standalone test app. It does **not** contain the Sada React app and does **not** change the web version.

**What it does:** plays a podcast through your Bluetooth earbuds and listens with the **phone's own microphone**. When it hears "Hey Sada" it pauses, beeps and speaks a fixed test sentence through the earbuds. When you say "Continue" it resumes where it stopped. It keeps running with the screen locked (foreground service with a permanent notification).

**What it doesn't do:** no Meta calls, no internet permission at all (nothing can leave the phone), no keys inside. It's a debug build, for testing only. Wake words are detected offline by sherpa-onnx (Apache-2.0) with its English GigaSpeech keyword model.

Built for: Infinix Hot 40 Pro (64-bit ARM), Android 13, HOCO Bluetooth earbuds.

---

## A. Put Stage 0 in your GitHub repository (from your phone)

You need two things in the repo: the workflow file and the app. On a phone, GitHub's upload page loses folder structure, so the app goes in as one zip.

1. **Workflow file.** In your repo on GitHub: **Add file → Create new file**.
   - Name: `.github/workflows/android-stage0.yml` (typing the `/` creates the folders).
   - Paste the contents of `android-stage0.yml` → **Commit changes**.
2. **The app.** **Add file → Upload files** → choose `android-poc.zip` → **Commit changes**. Upload the zip itself; don't unzip it. It must sit in the repository root, next to `package.json`.

The build starts by itself after the upload. Your web app files are not touched, and Vercel ignores both new files.

## B. Download the debug APK

1. Open the **Actions** tab → **"Android Stage 0: build debug APK"** → the newest run.
2. Wait for the green tick (about 5–10 minutes).
3. Scroll to **Artifacts** at the bottom → tap **sada-stage0-debug-apk-N**. You must be signed in to GitHub. It downloads as a `.zip`.

If the run fails, open the red step, copy the error lines and send them to Claude. To rebuild without changes: **Run workflow** on the same page.

## C. Install on the phone

1. Open the downloaded zip in the Files app and extract it. Inside is `sada-stage0-debug-N.apk`.
2. Tap the APK. Allow **Install unknown apps** for the Files app when asked.
3. If Play Protect warns about an unknown app, choose **Install anyway**.

This is a debug build for testing only. Builds normally install over the previous one. If Android ever says the app "conflicts with an existing package", uninstall Sada Stage 0 first. That happens if GitHub has discarded the saved debug key (after about a week without builds), and it also deletes the test results stored in the app, so copy the report first.

## D. Set up inside the app

1. **Allow microphone and notifications.**
2. **Let Sada run in the background (battery)** → Allow.
3. **Open Sada's app settings** → **Battery** → choose the option that doesn't restrict background use (often **Unrestricted** or **No restrictions**). Infinix XOS names and places these differently between versions. Also look for:
   - **Phone Master** app → auto-start / background management → allow Sada Stage 0;
   - in **Recent apps**, lock the Sada Stage 0 card (pull down or long-press it), if your phone offers it.

   These menu names are **not verified** for your XOS version. The app measures what actually happens instead: the status panel shows the standby bucket, "background restricted", battery optimization, and if Android stopped a test the report says when.
4. **Make the test episode** (Sada's six original episodes, read by the phone's voice, about 15 minutes, loops). Or choose your own podcast file.
5. Connect the HOCO earbuds.

## E. Tests

Before each test, check **Live status**. You want:
`✓ Phone mic listening, earbuds playing in music quality`.
If it says **CALL-QUALITY AUDIO**, or the podcast suddenly sounds like a phone call, note it. That is the main thing Stage 0 has to rule out.

**Test 1: quick check (2 minutes, screen on, phone in hand).**
Start test → say "Hey Sada" → expect beep, pause and the test sentence in the earbuds → say "Continue" → playback resumes where it stopped.

**Test 2: silence (30 minutes).** Choose *Silence test*. Podcast playing in the earbuds, phone locked in your pocket or on the table. **Don't say the wake words.** Every detection counts as a false activation.

**Test 3: walking (30 minutes or more).** Choose *Walking test*, start, lock the phone, put it in your pocket and walk.
- Every minute or two, say **"Hey Sada"** in a normal voice. Count how many times.
- If nothing happens, **tap an earbud once**: that marks a missed "Hey Sada".
- After the test sentence, say **"Continue"**. If it doesn't resume, tap an earbud once: it marks a missed "Continue" and resumes.

Earbud taps marking misses is a test convention: whether HOCO earbuds send their taps to the app is itself something to check. The event log shows `button` lines when they do.

**After each test:**
1. Unlock and type how many times you said "Hey Sada".
2. In *Wake detections*, tick any you didn't say.
3. Tap **Copy report** and paste it to Claude.

## What the report measures

- **Detections and misses:** detected vs your attempts, misses marked by tap, false activations per hour, and "Continue" heard while playing (always false).
- **Timing:** wake → paused, wake → response starts, Continue → playing, and the resume position error.
- **Routing:** microphone device, playback device, audio mode, Bluetooth call audio (SCO) on/off, and route changes during the test.
- **Microphone:** level (how well the phone mic hears you in a pocket), and whether Android silenced it.
- **Service:** uptime, screen on/off, heartbeat, battery use, and any stop by Android (detected from a heartbeat file).
- **Processing:** keyword engine cost per 100 ms of audio.

## Known limits (honest list)

- **Nothing has been tested on a real phone yet.** The first CI run is also the first compile: this code was written without an Android build environment.
- **sherpa-onnx's open bug:** a keyword that starts just as the spotter resets after 1.5 s of silence may be missed. Watch for misses right after quiet periods.
- **Test episode voice:** it's the phone's own TTS voice, which is also the voice of the response. For a narrator closer to real podcasts, use your own audio file.
- **"Hey Sarah" counts:** it's also listed as an alternative wake phrase (shown as `HEY_SADA_ALT`), to see whether it helps or causes false triggers.
