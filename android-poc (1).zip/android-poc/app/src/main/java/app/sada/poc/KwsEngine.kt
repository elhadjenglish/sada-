package app.sada.poc

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.SystemClock
import com.k2fsa.sherpa.onnx.KeywordSpotter
import com.k2fsa.sherpa.onnx.KeywordSpotterConfig
import com.k2fsa.sherpa.onnx.OnlineStream
import com.k2fsa.sherpa.onnx.getFeatureConfig
import com.k2fsa.sherpa.onnx.getKwsModelConfig
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

const val MODEL_DIR = "sherpa-onnx-kws-zipformer-gigaspeech-3.3M-2024-01-01"
private const val SAMPLE_RATE = 16000

/**
 * Continuous, offline keyword spotting on the phone's built-in microphone.
 * Audio never leaves the phone (the app has no internet permission).
 */
class KwsEngine(private val ctx: Context, private val onKeyword: (label: String, atMs: Long) -> Unit) {
    @Volatile private var running = false
    @Volatile var muted = false          // true while Sada speaks: results are ignored
    @Volatile private var flush = false  // drop buffered audio/state after Sada has spoken
    private var thread: Thread? = null
    private var record: AudioRecord? = null
    private var kws: KeywordSpotter? = null
    private var stream: OnlineStream? = null

    /** sensitivity: "default" uses the thresholds built into keywords.txt; others adjust them (experimental). */
    fun start(sensitivity: String): Boolean {
        if (running) return true
        try {
            if (kws == null) {
                val config = KeywordSpotterConfig(
                    featConfig = getFeatureConfig(SAMPLE_RATE, 80),
                    modelConfig = getKwsModelConfig(1)!!, // 1 = English GigaSpeech model (checked in CI)
                    keywordsFile = "$MODEL_DIR/keywords.txt",
                )
                kws = KeywordSpotter(ctx.assets, config)
            }
            val custom = customKeywords(sensitivity)
            stream = if (custom == null) kws!!.createStream() else kws!!.createStream(custom)
            Diag.keywordsMode = if (custom == null) "built-in thresholds" else "sensitivity: $sensitivity (experimental)"
        } catch (e: Throwable) {
            Diag.log("error", "Keyword engine failed to load: ${e.javaClass.simpleName}: ${e.message}")
            return false
        }

        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            // VOICE_RECOGNITION: tuned for speech recognition and does not put Bluetooth into call (SCO) mode.
            AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(minBuf, SAMPLE_RATE * 2))
        } catch (e: SecurityException) {
            Diag.log("error", "Microphone permission missing")
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            Diag.log("error", "Microphone could not be opened (another app may be using it)")
            rec.release()
            return false
        }
        val builtIn = builtInMic()
        if (builtIn != null) {
            val ok = rec.setPreferredDevice(builtIn)
            Diag.log("route", "Asked Android to use the ${AudioNames.describe(builtIn)}: ${if (ok) "accepted" else "refused"}")
        } else {
            Diag.log("route", "No built-in microphone listed by Android")
        }
        rec.startRecording()
        record = rec
        updateRoute()
        running = true
        thread = Thread({ loop(rec) }, "sada-kws").also { it.start() }
        return true
    }

    fun stop() {
        running = false
        try { thread?.join(1500) } catch (_: InterruptedException) {}
        thread = null
        try { record?.stop() } catch (_: Exception) {}
        record?.release()
        record = null
        stream = null
    }

    /** Called after Sada finishes speaking, so audio heard during the answer can't trigger anything. */
    fun flushAfterSpeaking() { flush = true }

    fun updateRoute() {
        val r = record ?: return
        Diag.micRoute = AudioNames.describe(r.routedDevice)
    }

    private fun builtInMic(): AudioDeviceInfo? {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
    }

    private fun loop(rec: AudioRecord) {
        val buf = ShortArray(SAMPLE_RATE / 10) // 100 ms
        var chunks = 0L
        var totalMs = 0.0
        var maxMs = 0.0
        var levelSum = 0.0
        var levelN = 0
        while (running) {
            val n = rec.read(buf, 0, buf.size)
            if (n <= 0) { SystemClock.sleep(20); continue }
            var sum = 0.0
            for (i in 0 until n) { val v = buf[i] / 32768.0; sum += v * v }
            val db = 20 * log10(sqrt(sum / n) + 1e-9)
            Diag.micLevelDb = db
            levelSum += db; levelN++
            if (levelN >= 50) { Diag.micLevelAvgDb = levelSum / levelN; levelSum = 0.0; levelN = 0 }

            val spotter = kws ?: continue
            val s = stream ?: continue
            if (flush) { spotter.reset(s); flush = false }
            val samples = FloatArray(n) { buf[it] / 32768.0f }
            val t0 = SystemClock.elapsedRealtimeNanos()
            s.acceptWaveform(samples, SAMPLE_RATE)
            while (spotter.isReady(s)) spotter.decode(s)
            val keyword = spotter.getResult(s).keyword
            val ms = (SystemClock.elapsedRealtimeNanos() - t0) / 1e6
            chunks++; totalMs += ms; if (ms > maxMs) maxMs = ms
            if (chunks % 20 == 0L) { Diag.kwsChunkMsAvg = totalMs / chunks; Diag.kwsChunkMsMax = maxMs }
            if (keyword.isNotBlank()) {
                spotter.reset(s)
                if (muted) Diag.log("ignored", "Heard $keyword while Sada was speaking")
                else onKeyword(keyword, System.currentTimeMillis())
            }
        }
    }

    /** Builds a keywords string with adjusted trigger thresholds from the bundled keywords.txt. */
    private fun customKeywords(sensitivity: String): String? {
        if (sensitivity == "default") return null
        val delta = if (sensitivity == "more") -0.08 else 0.08
        val lines = ctx.assets.open("$MODEL_DIR/keywords.txt").bufferedReader().readLines().filter { it.isNotBlank() }
        return lines.joinToString("/") { line ->
            val m = Regex("#([0-9.]+)").find(line)
            if (m != null) {
                val v = (m.groupValues[1].toDouble() + delta).coerceIn(0.05, 0.9)
                line.replace(m.value, "#" + "%.2f".format(java.util.Locale.US, v))
            } else line
        }
    }
}
