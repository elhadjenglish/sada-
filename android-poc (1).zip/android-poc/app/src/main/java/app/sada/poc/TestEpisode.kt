package app.sada.poc

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Renders Sada's six original episodes with the phone's voice into one WAV file (about 15 minutes, played on loop). */
object TestEpisode {
    fun file(ctx: Context) = File(ctx.filesDir, "test-episode.wav")

    /** Runs on a background thread. progress(done, total); returns null on success or an error message. */
    fun generate(ctx: Context, progress: (Int, Int) -> Unit): String? {
        val ready = CountDownLatch(1)
        var ok = false
        lateinit var tts: TextToSpeech
        tts = TextToSpeech(ctx.applicationContext) { status -> ok = status == TextToSpeech.SUCCESS; ready.countDown() }
        if (!ready.await(15, TimeUnit.SECONDS) || !ok) return "The phone's text-to-speech engine did not start."
        tts.setLanguage(Locale.US)
        val parts = ArrayList<File>()
        try {
            for ((i, text) in EPISODE_TEXTS.withIndex()) {
                progress(i, EPISODE_TEXTS.size)
                val out = File(ctx.cacheDir, "ep$i.wav")
                val done = CountDownLatch(1)
                var failed = false
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { done.countDown() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { failed = true; done.countDown() }
                })
                val r = tts.synthesizeToFile(text, Bundle(), out, "ep$i")
                if (r != TextToSpeech.SUCCESS) return "The phone's voice could not render episode ${i + 1}."
                if (!done.await(180, TimeUnit.SECONDS) || failed || !out.exists()) return "Rendering episode ${i + 1} failed or timed out."
                parts.add(out)
            }
            progress(EPISODE_TEXTS.size, EPISODE_TEXTS.size)
            return Wav.concat(parts, file(ctx), silenceSeconds = 1.5)
        } finally {
            tts.shutdown()
            parts.forEach { it.delete() }
        }
    }
}

/** Minimal WAV reader/writer for joining the rendered episodes. */
object Wav {
    private fun le32(b: ByteArray, i: Int) = (b[i].toInt() and 0xff) or ((b[i + 1].toInt() and 0xff) shl 8) or
        ((b[i + 2].toInt() and 0xff) shl 16) or ((b[i + 3].toInt() and 0xff) shl 24)
    private fun le16(b: ByteArray, i: Int) = (b[i].toInt() and 0xff) or ((b[i + 1].toInt() and 0xff) shl 8)
    private fun put32(v: Int) = byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())

    /** Returns (fmt chunk, pcm data) or null. Tolerates engines that write an unknown data length. */
    fun read(f: File): Pair<ByteArray, ByteArray>? {
        val b = f.readBytes()
        if (b.size < 44 || String(b, 0, 4, Charsets.US_ASCII) != "RIFF" || String(b, 8, 4, Charsets.US_ASCII) != "WAVE") return null
        var i = 12
        var fmt: ByteArray? = null
        var data: ByteArray? = null
        while (i + 8 <= b.size) {
            val id = String(b, i, 4, Charsets.US_ASCII)
            val len = le32(b, i + 4)
            val start = i + 8
            if (id == "data") {
                val end = if (len <= 0 || start + len > b.size) b.size else start + len
                data = b.copyOfRange(start, end)
                break
            }
            if (len < 0 || start + len > b.size) break
            if (id == "fmt ") fmt = b.copyOfRange(start, start + len)
            i = start + len + (len and 1)
        }
        return if (fmt != null && data != null) Pair(fmt, data) else null
    }

    fun concat(inputs: List<File>, out: File, silenceSeconds: Double): String? {
        val decoded = inputs.mapNotNull { read(it) }
        if (decoded.isEmpty()) return "The rendered audio could not be read."
        val fmt = decoded[0].first
        val same = decoded.filter { it.first.contentEquals(fmt) }
        val rate = le32(fmt, 4)
        val blockAlign = le16(fmt, 12).coerceAtLeast(1)
        val silence = ByteArray(((rate * silenceSeconds).toInt()) * blockAlign)
        val total = same.sumOf { it.second.size + silence.size }
        FileOutputStream(out).use { o ->
            o.write("RIFF".toByteArray(Charsets.US_ASCII)); o.write(put32(4 + 8 + fmt.size + 8 + total))
            o.write("WAVE".toByteArray(Charsets.US_ASCII))
            o.write("fmt ".toByteArray(Charsets.US_ASCII)); o.write(put32(fmt.size)); o.write(fmt)
            o.write("data".toByteArray(Charsets.US_ASCII)); o.write(put32(total))
            for (d in same) { o.write(d.second); o.write(silence) }
        }
        return null
    }
}
