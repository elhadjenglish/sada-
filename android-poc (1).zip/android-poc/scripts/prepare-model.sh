#!/usr/bin/env bash
# Downloads the English keyword-spotting model and converts Sada's phrases into model tokens.
set -euo pipefail
: "${KWS_MODEL:?set KWS_MODEL}"
: "${SHERPA_VERSION:?set SHERPA_VERSION}"
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="${RUNNER_TEMP:-/tmp}/kws"
rm -rf "$WORK"; mkdir -p "$WORK"

echo "== Keyword model: $KWS_MODEL"
curl -fsSL -o "$WORK/model.tar.bz2" "https://github.com/k2-fsa/sherpa-onnx/releases/download/kws-models/${KWS_MODEL}.tar.bz2"
tar xjf "$WORK/model.tar.bz2" -C "$WORK"
M="$WORK/$KWS_MODEL"
ls -la "$M"
for f in tokens.txt bpe.model; do
  [ -f "$M/$f" ] || { echo "::error::$f is missing from $KWS_MODEL"; exit 1; }
done
ls "$M"/*.onnx >/dev/null 2>&1 || { echo "::error::No .onnx model files in $KWS_MODEL"; exit 1; }

echo "== Python tools (pinned, no fallback to other versions)"
python3 -m pip install --quiet --disable-pip-version-check "sherpa-onnx==${SHERPA_VERSION}" -r "$HERE/requirements-ci.txt"
python3 - <<'PY'
import importlib, sys
missing = []
for name in ["sherpa_onnx", "click", "sentencepiece", "pypinyin", "numpy"]:
    try:
        m = importlib.import_module(name)
        print(f"ok  {name} {getattr(m, '__version__', '')}")
    except Exception as e:
        missing.append(f"{name}: {e}")
if missing:
    print("::error::Missing Python modules: " + "; ".join(missing)); sys.exit(1)
PY
# Fails here, with the module name, if the CLI needs anything else.
sherpa-onnx-cli text2token --help >/dev/null

echo "== Converting phrases to tokens"
sherpa-onnx-cli text2token --tokens "$M/tokens.txt" --tokens-type bpe --bpe-model "$M/bpe.model" \
  keywords/keywords-input.txt "$WORK/keywords.txt"
echo "-- keywords.txt (tokens):"; cat "$WORK/keywords.txt"
lines_in=$(grep -cve '^\s*$' keywords/keywords-input.txt)
lines_out=$(grep -cve '^\s*$' "$WORK/keywords.txt" || true)
if [ "$lines_out" != "$lines_in" ]; then
  echo "::error::Expected $lines_in keyword lines, got $lines_out"; exit 1
fi

echo "== Copying model into the app"
A="app/src/main/assets/$KWS_MODEL"
rm -rf app/src/main/assets; mkdir -p "$A"
cp "$M"/*.onnx "$M/tokens.txt" "$A"/
cp "$WORK/keywords.txt" "$A/keywords.txt"   # replaces the model's sample keywords
ls -la "$A"
echo "MODEL_DIR=$M" >> "${GITHUB_ENV:-/dev/null}"
echo "KEYWORDS_FILE=$WORK/keywords.txt" >> "${GITHUB_ENV:-/dev/null}"
