# Sada Stage 0: native wake-word test (Android)

A small standalone test app. It does **not** contain the Sada React app and does **not** change the web version.

**What it does:** plays a podcast through your earbuds or the phone speaker and listens with the **phone's own microphone** (with echo cancellation when the podcast is on the speaker). On "Hey Sada" it pauses, records your question (with the earbud microphone when earbuds are connected), plays your question back so you can hear how well it was captured, and resumes on "Continue". It keeps running with the screen locked (foreground service with a permanent notification).

**What it doesn't do:** no Meta calls, no internet permission at all (nothing can leave the phone), no keys inside. It's a debug build, for testing only. Wake words are detected offline by sherpa-onnx (Apache-2.0) with its English GigaSpeech keyword model.

Built for: Infinix Hot 40 Pro (64-bit ARM), Android 13, HOCO Bluetooth earbuds.

---

## A. Put Stage 0 in your GitHub repository (from your phone)

You need two things in the repo: the workflow file and the app. On a phone, GitHub's upload page loses folder structure, so the app goes in as one zip.

1. **Workflow file.** In your repo on GitHub: **Add file → Create new file**.
   - Name: `.github/workflows/android-stage0.yml` (typing the `/` creates the folders).
   - Paste the contents of `android-stage0.yml` → **Commit changes**.
2. **The app.** **Add file → Upload files** → choose `android-poc.zip` → **Commit changes**. Upload the zip itself; don't unzip it. It must sit in the repository root, next to `package.json`.

The build starts by itself after the upload. Your web app files are not touched, and Vercel ignores both new files.

## B. Download the debug APK

1. Open the **Actions** tab → **"Android Stage 0: build debug APK"** → the newest run.
2. Wait for the green tick (about 5–10 minutes).
3. Scroll to **Artifacts** at the bottom → tap **sada-stage0-debug-apk-N**. You must be signed in to GitHub. It downloads as a `.zip`.

If the run fails, open the red step, copy the error lines and send them to Claude. To rebuild without changes: **Run workflow** on the same page.

## C. Install on the phone

1. Open the downloaded zip in the Files app and extract it. Inside is `sada-stage0-debug-N.apk`.
2. Tap the APK. Allow **Install unknown apps** for the Files app when asked.
3. If Play Protect warns about an unknown app, choose **Install anyway**.

This is a debug build for testing only. Builds normally install over the previous one. If Android ever says the app "conflicts with an existing package", uninstall Sada Stage 0 first. That happens if GitHub has discarded the saved debug key (after about a week without builds), and it also deletes the test results stored in the app, so copy the report first.

## D. Set up inside the app

1. **Allow microphone and notifications.**
2. **Let Sada run in the background (battery)** → Allow.
3. **Open Sada's app settings** → **Battery** → choose the option that doesn't restrict background use (often **Unrestricted** or **No restrictions**). Infinix XOS names and places these differently between versions. Also look for:
   - **Phone Master** app → auto-start / background management → allow Sada Stage 0;
   - in **Recent apps**, lock the Sada Stage 0 card (pull down or long-press it), if your phone offers it.

   These menu names are **not verified** for your XOS version. The app measures what actually happens instead: the status panel shows the standby bucket, "background restricted", battery optimization, and if Android stopped a test the report says when.
4. **Make the test episode** (Sada's six original episodes, read by the phone's voice, about 15 minutes, loops). Or choose your own podcast file.
5. Connect the HOCO earbuds.

## E. How this build works

**Podcast through the phone speaker.** The podcast is now played by Sada's own decoder instead of Android's media player, so Sada knows exactly what the speaker is playing. An echo canceller subtracts that sound from the phone microphone before wake-word detection, keeping your voice. Without this, the speaker drowned out "Hey Sada", which is why detection failed without earbuds. It is switched on only when the podcast plays through the speaker; with earbuds there is no echo to remove.

**Asking a question.** After "Hey Sada" the podcast pauses and Sada switches to the best microphone:
- **Earbuds connected:** the earbud microphone, close to your mouth. This needs Bluetooth "call mode", which only happens while the podcast is paused. Wait for the beep (about 1–2 s), then ask.
- **No earbuds:** the phone microphone. Ask right after the beep.

Sada records until you stop talking. Stage 0 has no AI answer yet, so it says **"Here is what I heard"** and **plays your question back**, so you can judge with your own ears whether it was captured clearly. Then say **"Continue"**. The recording is kept in memory only and discarded after the playback.

**Detection uses two versions of the microphone signal** and accepts "Hey Sada" from either; the report shows which one caught it.

## F. Tests: in this order, copy the report after each

1. **Self-test** (no microphone): tap **Run detector self-test**.
2. **Earbuds, phone in hand, screen on (2 min).** Play the podcast. Say "Hey Sada", wait for the beep, ask "What does reliable mean?", listen to the playback, then say "Continue". Repeat 5 times.
3. **Earbuds, phone in pocket, screen locked, walking (10 min).** The same cycle 5–10 times. Listen to whether the playback of your question is clear.
4. **No earbuds, podcast on the speaker, phone in hand (2 min).** Say "Hey Sada" 5 times over the podcast. Check the status line **Echo cancellation: ON, echo reduced by … dB**.
5. **Same as 4 with echo cancellation switched off** (untick it). This shows how much it helps on your phone.
6. **No earbuds, phone in pocket, screen locked (10 min).** The full cycle.
7. **30-minute silence test and 30-minute walking test** (as before), once 2–6 work.

**What to listen and look for:**
- **The playback of your question.** Can you understand every word? This is the real test of question capture.
- **Echo cancellation line:** "echo reduced by N dB". On the speaker, more than 15 dB is good; under 6 dB means it isn't working on this phone.
- **Last question line:** which microphone was used, how long it took to get ready, speech level and SNR (speech above background; 15 dB or more is comfortable), and why recording ended.
- **Detections by stream:** which processed signal caught "Hey Sada".

## G. What the report measures

- **Detections and misses:** detected vs your attempts, misses marked by tap, false activations per hour, and "Continue" heard while playing (always false).
- **Timing:** wake → paused, wake → response starts, Continue → playing, and the resume position error.
- **Routing:** microphone device, playback device, audio mode, Bluetooth call audio (SCO) on/off, and route changes during the test.
- **Microphone:** level (how well the phone mic hears you in a pocket), and whether Android silenced it.
- **Service:** uptime, screen on/off, heartbeat, battery use, and any stop by Android (detected from a heartbeat file).
- **Processing:** keyword engine cost per 100 ms of audio.

## H. Known limits (honest list)

- **First compile:** this build has not been compiled yet. The Java signal-processing core and the flow logic were compiled and tested on the build machine (31 tests, simulated signals); the Android Kotlin code compiles for the first time in GitHub Actions.
- **Echo cancellation on real hardware:** it was tested only on synthetic echo. The Infinix speaker, its distortion at high volume, and how accurately Android reports playback and recording timestamps decide the real result. The status line measures it.
- **Pocket plus speaker** is the hardest case: the speaker and microphone are centimetres apart inside fabric. Even with good cancellation, very loud playback may still hide your voice. Moderate volume will work better.
- **Earbud microphone:** switching takes 1–2 s and some earbuds play a tone. Whether the HOCO EW51 microphone is clear in call mode is untested.
- **"Sada" is an unusual word** for the keyword model; detection still depends on how it hears your pronunciation.
- **sherpa-onnx bug:** a keyword starting just after a 1.5 s silence may be missed.

## I. Investigation: intermittent "Hey Sada" detection (November 2026)

### Probable causes (from code, Android documentation and the device report; to be confirmed on the phone)

1. **Input level far below what the model handles well.** Android requires the `VOICE_RECOGNITION` source to have no automatic gain and a fixed calibration: 90 dB SPL ≈ -22 dBFS (CDD 5.4.2). Speech reaching a phone at chest height or in a pocket is about 20–30 dB quieter, so it arrives around -45 to -55 dBFS. That is consistent with the device report (average -70 dBFS, peak 0.08). The self-tests feed the phone's voice at normal levels (about -20 dBFS), which is why they passed while live detection failed. The previous gain control needed about 2.4 s of speech to add 20 dB (too slow for "Hey Sada"), and the second detector stream was the raw signal.
2. **Leaked call-mode state.** Choosing the earbud microphone selects a Bluetooth communication device. In Android's audio policy that forces other recordings to the headset input. If the test was stopped while the switch was in progress, the request was never withdrawn, so the "phone microphone" recorder could capture an idle Bluetooth input (near-silence) in later tests. Android clears such a request when the requesting process dies: that matches "works again after reinstalling".
3. **Unverified recovery.** Nothing checked that the recorder was really back on the phone microphone after a question (Android applies routing changes asynchronously), and a stalled question step could leave the detector muted for the rest of a session.

### Changes

- **Calibration:** a fixed +20 dB gain (+10 dB for the plain-microphone option) with a soft limiter, before everything else. The detector gets a calibrated stream (deterministic) and an adaptive-gain stream; gain control now reacts within about 0.5 s.
- **Call-mode guard:** every earbud-mic path withdraws its request, including stopping mid-switch. Stopping a test always withdraws it. Sada waits until Android reports a clean state before reopening the phone mic, and repairs leftover call mode while listening (logged as "call-mode repair").
- **Recorder self-checks:** about once a second Sada confirms the recorder is on the phone microphone, and reopens it if it was routed elsewhere or delivers 3 s of digital silence (logged as "mic recovery").
- **Watchdog:** any question step stuck for 30 s returns to waiting for "Continue" with the detector listening.
- **Evidence:**
  - every second of audio is classified (silence / noise only / quiet speech / clipped / usable speech);
  - levels are reported at each stage (raw → calibrated → detector);
  - speech seconds with no detector output at all are counted;
  - the self-test runs a level sweep on the phone, and the build machine runs one on real recorded speech;
  - an optional, consented 10-second microphone check checks whether a fresh detector finds "Hey Sada" in what was recorded, as received and at 0/10/20/30 dB of gain.

### Wake-word engines considered

| Engine | Licence / cost | Offline | Custom "Hey Sada" | Decision |
|---|---|---|---|---|
| sherpa-onnx keyword spotting | Apache-2.0, free | Yes | Any phrase, no training | **Kept.** The failures trace to the audio pipeline, not to the engine. |
| Picovoice Porcupine | AccessKey validated online at start-up (needs internet permission). Free-tier keys were reported discontinued after 30 June 2026, with no non-commercial tier. Custom models carry licence limits. | Detection yes; key check no | Trained in Picovoice Console | **Not usable here** without an enterprise contract, so no fair device comparison was possible. Design lessons taken: plain `MIC` source, 512-sample frames, one recorder feeding listeners. |
| openWakeWord / microWakeWord | Open code; pre-trained openWakeWord models are non-commercial; custom models need training | Yes | Requires training a model | Possible later if sherpa-onnx accuracy is the limit once levels are right. |

A real A/B comparison between engines on this phone is only meaningful once the pipeline delivers correct levels. Steps 2–4 of the tests show whether it now does.

## J. Test plan for this build (one variable at a time; copy the report after each)

**Before anything:** Run detector self-test. Step 4 (level sweep) and step 5 (build machine, real speech) show how much detection depends on input level.

Use the same quiet room, normal speaking voice, earbuds connected, podcast playing on the earbuds, and 10 attempts of "Hey Sada" per test, a few seconds apart. Write down how many times you said it.

| Test | Condition | What changes |
|---|---|---|
| A | Phone 5–10 cm from the mouth | distance only |
| B | Phone at chest, 20–30 cm | distance only |
| C | Phone in a trouser or jacket pocket | distance + fabric |
| D | As C, screen locked | screen only |
| E | As D, walking | movement and noise |
| F | As D, 30 minutes, say "Hey Sada" every 2–3 min | duration |
| G | Stop and start the test 5 times (no reinstall), 3 attempts each | restarts |
| H | Silence test for 30 minutes, podcast on the earbuds, then on the speaker | false activations |

**During B, run one microphone check** (with your consent) and say "Hey Sada" 2–3 times while it records. Its result line answers directly whether the phrase was in the audio, and at what gain a fresh detector finds it.

**In each report, the most useful lines are:**
- **Levels:** raw → detector, in dBFS.
- **Seconds:** how much was silence, noise, quiet speech or usable speech.
- **Speech seconds with no detector output.**
- **Mic recoveries and call-mode repairs:** these should stay at 0; if not, the log says why.
- **Microphone check.**

## K. Reliability over time, question capture, activation (this build)

### Findings
- **Questions ran to the 12-second limit.** The end-of-speech detector listened to the audio after gain control. After a quiet question, gain control had raised the background, so silence still looked like speech. Reproduced in a simulation test; the detector now runs on the signal before gain control (the playback still uses the gain-controlled audio). Silence before you start speaking still works, and the recording is still trimmed to the spoken part.
- **Detection got weaker with use (likely cause).**
  - Every test start, self-test and microphone check created new keyword detectors (each an ONNX Runtime session with native memory and threads), and none were ever released. Android keeps the app's process alive between tests, so these piled up until the process died, for example on reinstall. That matches "fresh install good, gradually worse".
  - Smaller items: experimental settings survived updates, and the event log file grew without limit.
  - This build fixes all three and measures the result on the phone (Health line).
- **"Speech with no detector output"** is not a failure count. It included ordinary talking and question speech. It now counts only while listening, and the report says to compare it with your attempts.
- **"Inconsistent gain tests" in the microphone check:** different gains give different results when a phrase sits near the detector's threshold. It is evidence that detection is borderline for that recording, not that gain is broken.

### Changes
- **One live detector per app process,** reused across tests. The self-test and microphone check reuse their own cached detectors. Every stream is released after use.
- **Stream refresh:** live streams are refreshed every ~2 minutes during quiet moments, never mid-phrase, so nothing accumulates over a long session.
- **Health check:** every 5 minutes, while just listening (never during a question), a "Hey Sada" recorded in the phone's voice at session start is run through the live detector. Two failures in a row: the detector is rebuilt and checked again. All logged.
- **Health measurements:** processing speed vs real time, microphone capture lag and dropped audio (overruns), native memory, threads, and open detectors/streams.
- **Settings:** experimental options are reset once for this version; "Restore default settings" button.
- **Earbuds disconnect:** the podcast pauses instead of moving to the phone speaker.

### Activation
- **Voice:** "Hey Sada".
- **Earbuds:** one tap = pause / continue; two quick taps or the earbuds' next-track gesture = Ask Sada; while asking, a tap ends the question.
- **Notification:** lock-screen buttons "Ask Sada" and "Pause / Continue". Plus an "Ask Sada now" button in the app.
- **All lead into the same flow:** pause → question → playback → "Continue".
- **Volume-button gesture: postponed.**
  - Android gives background apps no general access to the volume keys. The only legitimate route is for Sada's media session to take over volume control entirely ("remote volume"), so system volume and Bluetooth volume would no longer behave normally.
  - Every press must still change the volume, so a gesture also changes the volume.
  - Buttons get pressed by accident in pockets, which would mean accidental activations.
  - Earbud controls give the same "without taking the phone out" result through a mechanism Android supports. Revisit if earbud controls prove insufficient.

### Device test plan for this build
1. **Earbud controls.** Play the podcast with the earbuds connected and the phone locked in your pocket. Single-tap: it pauses; single-tap again: it continues. Double-tap: Sada asks for your question. Check the log for `button` lines: they show which key each earbud gesture sends.
2. **Question ending.** "Hey Sada" → wait 3 s → ask → stop talking. The question should end about 1 s after you stop (the "Last question" line says "you stopped talking", not "maximum length"). Repeat 5 times.
3. **Long-term reliability:**
   - On one day without reinstalling, run several test sessions (start/stop at least 5 times), the self-test 3 times, and one microphone check.
   - Then run 10 "Hey Sada" attempts at chest level.
   - Compare with 10 attempts right after installing this build.
   - Send the Health line from both.
   - Native memory and threads should stay roughly flat; the detector check should keep passing.
4. **Two hours of listening.** Play for 2 hours locked in the pocket, with occasional questions. Send the report: health checks passed/failed, rebuilds, overruns, processing speed.
5. **Earbuds disconnect.** Switch the earbuds off while the podcast plays: it should pause, not continue on the speaker.
