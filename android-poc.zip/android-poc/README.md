# Sada Stage 0: native wake-word test (Android)

A small standalone test app. It does **not** contain the Sada React app and does **not** change the web version.

**What it does:** plays a podcast through your Bluetooth earbuds and listens with the **phone's own microphone**. When it hears "Hey Sada" it pauses, beeps and speaks a fixed test sentence through the earbuds. When you say "Continue" it resumes where it stopped. It keeps running with the screen locked (foreground service with a permanent notification).

**What it doesn't do:** no Meta calls, no internet permission at all (nothing can leave the phone), no keys inside. It's a debug build, for testing only. Wake words are detected offline by sherpa-onnx (Apache-2.0) with its English GigaSpeech keyword model.

Built for: Infinix Hot 40 Pro (64-bit ARM), Android 13, HOCO Bluetooth earbuds.

---

## A. Put Stage 0 in your GitHub repository (from your phone)

You need two things in the repo: the workflow file and the app. On a phone, GitHub's upload page loses folder structure, so the app goes in as one zip.

1. **Workflow file.** In your repo on GitHub: **Add file → Create new file**.
   - Name: `.github/workflows/android-stage0.yml` (typing the `/` creates the folders).
   - Paste the contents of `android-stage0.yml` → **Commit changes**.
2. **The app.** **Add file → Upload files** → choose `android-poc.zip` → **Commit changes**. Upload the zip itself; don't unzip it. It must sit in the repository root, next to `package.json`.

The build starts by itself after the upload. Your web app files are not touched, and Vercel ignores both new files.

## B. Download the debug APK

1. Open the **Actions** tab → **"Android Stage 0: build debug APK"** → the newest run.
2. Wait for the green tick (about 5–10 minutes).
3. Scroll to **Artifacts** at the bottom → tap **sada-stage0-debug-apk-N**. You must be signed in to GitHub. It downloads as a `.zip`.

If the run fails, open the red step, copy the error lines and send them to Claude. To rebuild without changes: **Run workflow** on the same page.

## C. Install on the phone

1. Open the downloaded zip in the Files app and extract it. Inside is `sada-stage0-debug-N.apk`.
2. Tap the APK. Allow **Install unknown apps** for the Files app when asked.
3. If Play Protect warns about an unknown app, choose **Install anyway**.

This is a debug build for testing only. Builds normally install over the previous one. If Android ever says the app "conflicts with an existing package", uninstall Sada Stage 0 first. That happens if GitHub has discarded the saved debug key (after about a week without builds), and it also deletes the test results stored in the app, so copy the report first.

## D. Set up inside the app

1. **Allow microphone and notifications.**
2. **Let Sada run in the background (battery)** → Allow.
3. **Open Sada's app settings** → **Battery** → choose the option that doesn't restrict background use (often **Unrestricted** or **No restrictions**). Infinix XOS names and places these differently between versions. Also look for:
   - **Phone Master** app → auto-start / background management → allow Sada Stage 0;
   - in **Recent apps**, lock the Sada Stage 0 card (pull down or long-press it), if your phone offers it.

   These menu names are **not verified** for your XOS version. The app measures what actually happens instead: the status panel shows the standby bucket, "background restricted", battery optimization, and if Android stopped a test the report says when.
4. **Make the test episode** (Sada's six original episodes, read by the phone's voice, about 15 minutes, loops). Or choose your own podcast file.
5. Connect the HOCO earbuds.

## E. Tests: do them in this order

The first device test detected nothing, and that report can't tell a broken detector apart from a voice it couldn't hear. These steps separate the two. Copy the report after each one.

**Step 1: detector self-test (no microphone, 30 seconds).** Tap **Run detector self-test**. It shows three results:
1. **Keywords:** "Hey Sada", "Hey Sarah" and "Continue" are valid for the model (✓ or the exact problem).
2. **Recorded speech:** the model's own sample recordings go through the same Android code as the microphone, and the result is compared with what the build machine got. "Same as reference" means the Android detector works.
3. **Phone voice:** "Hey Sada" and "Continue" spoken by the phone's text-to-speech are fed in digitally, with no microphone or room noise.

**Step 2: listen-only test (2 minutes, quiet room, phone in your hand).** Untick **Play the podcast**, start the test, and say "Hey Sada" five times, a few seconds apart, about 30 cm from the phone. The response is spoken through the earbuds or speaker, then say "Continue". Nothing is playing, so nothing can drown out your voice.

**Step 3: same as step 2 with "Plain microphone" selected.** This shows whether Android's speech-recognition processing helps or hurts on the Infinix.

**Step 4: with playback, earbuds connected.** Tick **Play the podcast**, connect the HOCO earbuds, and check the status says `✓ Phone mic listening, earbuds playing in music quality`. Then repeat the five "Hey Sada" attempts.

**Steps 5 and 6: only after the earlier steps work.** The 30-minute silence test and 30-minute walking test, locked in your pocket, as described below.

- **Silence test:** choose *Silence test*. Play the podcast in the earbuds, lock the phone, and don't say the wake words. Every detection counts as false.
- **Walking test:** choose *Walking test*, lock the phone and walk. Say "Hey Sada" every minute or two and count your attempts. Tap an earbud once if nothing happens; that marks a miss. After the response, say "Continue"; if it doesn't resume, tap once.

**What the new diagnostics show:**
- **Reached detector:** how many seconds of microphone audio actually went into the detector, plus empty reads, all-zero buffers, clipping and peak level. If this number doesn't grow while the test runs, audio isn't arriving.
- **Mic input:** the sample rate, channels and format Android actually delivers, not just what was requested.
- **Raw detector outputs:** everything the detector reported, including anything ignored before playback started or while Sada was speaking.
- **Near misses:** a second, very sensitive listener that never acts and only logs. It means "the detector almost heard a keyword". sherpa-onnx doesn't expose per-keyword scores, so this is the closest honest substitute.

No audio is recorded or saved; only these numbers and the detected keyword names are logged, on the phone.

## What the report measures

- **Detections and misses:** detected vs your attempts, misses marked by tap, false activations per hour, and "Continue" heard while playing (always false).
- **Timing:** wake → paused, wake → response starts, Continue → playing, and the resume position error.
- **Routing:** microphone device, playback device, audio mode, Bluetooth call audio (SCO) on/off, and route changes during the test.
- **Microphone:** level (how well the phone mic hears you in a pocket), and whether Android silenced it.
- **Service:** uptime, screen on/off, heartbeat, battery use, and any stop by Android (detected from a heartbeat file).
- **Processing:** keyword engine cost per 100 ms of audio.

## Known limits (honest list)

- **Nothing has been tested on a real phone yet.** The first CI run is also the first compile: this code was written without an Android build environment.
- **sherpa-onnx's open bug:** a keyword that starts just as the spotter resets after 1.5 s of silence may be missed. Watch for misses right after quiet periods.
- **Test episode voice:** it's the phone's own TTS voice, which is also the voice of the response. For a narrator closer to real podcasts, use your own audio file.
- **"Hey Sarah" counts:** it's also listed as an alternative wake phrase (shown as `HEY_SADA_ALT`), to see whether it helps or causes false triggers.
