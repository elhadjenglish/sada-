package app.sada.poc

import org.junit.Assert.assertEquals
import org.junit.Test

class PocStateMachineTest {
    private fun started() = PocStateMachine().also { it.start() }

    @Test fun fullCycle() {
        val m = started()
        assertEquals(listOf(StepKind.WAKE_DETECTED, StepKind.PAUSE_AND_ANSWER), m.onKeyword("HEY_SADA"))
        assertEquals(Phase.ANSWERING, m.phase)
        assertEquals(listOf(StepKind.LISTEN_FOR_CONTINUE), m.onAnswerDone())
        assertEquals(listOf(StepKind.CONTINUE_DETECTED, StepKind.RESUME), m.onKeyword("CONTINUE"))
        assertEquals(Phase.LISTENING, m.phase)
    }

    @Test fun alternativeWakeLabelCounts() {
        assertEquals(listOf(StepKind.WAKE_DETECTED, StepKind.PAUSE_AND_ANSWER), started().onKeyword("HEY_SADA_ALT"))
    }

    @Test fun continueWhilePlayingIsAFalseTriggerAndDoesNothing() {
        val m = started()
        assertEquals(listOf(StepKind.CONTINUE_WHILE_PLAYING), m.onKeyword("CONTINUE"))
        assertEquals(Phase.LISTENING, m.phase)
    }

    @Test fun nothingIsActedOnWhileSpeaking() {
        val m = started()
        m.onKeyword("HEY_SADA")
        assertEquals(listOf(StepKind.IGNORED_WHILE_SPEAKING), m.onKeyword("CONTINUE"))
        assertEquals(listOf(StepKind.IGNORED_WHILE_SPEAKING), m.onKeyword("HEY_SADA"))
        assertEquals(Phase.ANSWERING, m.phase)
    }

    @Test fun wakeWhilePausedDoesNotResume() {
        val m = started()
        m.onKeyword("HEY_SADA"); m.onAnswerDone()
        assertEquals(listOf(StepKind.WAKE_WHILE_PAUSED), m.onKeyword("HEY_SADA"))
        assertEquals(Phase.WAIT_CONTINUE, m.phase)
    }

    @Test fun earbudTapMarksMissesAndCanResume() {
        val m = started()
        assertEquals(listOf(StepKind.MISSED_WAKE), m.onEarbudTap())
        assertEquals(Phase.LISTENING, m.phase)
        m.onKeyword("HEY_SADA"); m.onAnswerDone()
        assertEquals(listOf(StepKind.MISSED_CONTINUE, StepKind.RESUME), m.onEarbudTap())
        assertEquals(Phase.LISTENING, m.phase)
    }

    @Test fun stoppedIgnoresEverything() {
        val m = PocStateMachine()
        assertEquals(emptyList<StepKind>(), m.onKeyword("HEY_SADA"))
        assertEquals(emptyList<StepKind>(), m.onEarbudTap())
        assertEquals(emptyList<StepKind>(), m.onAnswerDone())
    }

    @Test fun unknownLabel() {
        assertEquals(listOf(StepKind.UNKNOWN_KEYWORD), started().onKeyword("HELLO_WORLD"))
    }
}
