package app.sada.poc;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Stage 0 interaction flow, free of Android classes so it is unit-tested on the build machine.
 *
 *   LISTENING ──"Hey Sada"──▶ ARMING (podcast paused, question microphone getting ready)
 *       ▲                         │ input ready
 *       │                         ▼
 *       │                      ASKING (capturing the question until the user stops talking)
 *       │                         │ question finished (or nothing heard)
 *       │                         ▼
 *       │                      ANSWERING (replaying what was heard, then "say continue")
 *       │                         │ done
 *       │                         ▼
 *       └──────"Continue"──── WAIT_CONTINUE
 */
public final class PocStateMachine {
    public enum Phase { STOPPED, LISTENING, ARMING, ASKING, ANSWERING, WAIT_CONTINUE }

    public enum StepKind {
        WAKE_DETECTED,            // "Hey Sada" while the podcast plays
        PAUSE_PODCAST,            // pause playback now (exact position kept)
        PREPARE_QUESTION_INPUT,   // switch to the best microphone for the question
        START_CAPTURE,            // start recording the question
        STOP_CAPTURE,             // stop recording (user tapped)
        ANSWER,                   // replay what was heard (Stage 0 has no AI answer)
        LISTEN_FOR_CONTINUE,      // answer finished; wait for "Continue"
        CONTINUE_DETECTED,
        RESUME,                   // resume at the saved position
        CONTINUE_WHILE_PLAYING,   // "Continue" heard while playing: a false trigger by definition
        IGNORED_BUSY,             // keyword heard while preparing, asking or answering: ignored
        WAKE_WHILE_PAUSED,        // "Hey Sada" while waiting for "Continue"
        MISSED_WAKE,              // earbud tap while playing = "I said Hey Sada, nothing happened"
        MISSED_CONTINUE,          // earbud tap while waiting = "I said Continue, nothing happened" (also resumes)
        UNKNOWN_KEYWORD,
    }

    private Phase phase = Phase.STOPPED;

    public Phase getPhase() { return phase; }
    public void start() { phase = Phase.LISTENING; }
    public void stop() { phase = Phase.STOPPED; }

    public static boolean isWake(String label) { return label.trim().toUpperCase().startsWith("HEY_SADA"); }
    public static boolean isContinue(String label) { return label.trim().toUpperCase().startsWith("CONTINUE"); }

    public List<StepKind> onKeyword(String label) {
        boolean wake = isWake(label), cont = isContinue(label);
        if (!wake && !cont) return list(StepKind.UNKNOWN_KEYWORD);
        switch (phase) {
            case STOPPED: return Collections.emptyList();
            case LISTENING:
                if (wake) { phase = Phase.ARMING; return list(StepKind.WAKE_DETECTED, StepKind.PAUSE_PODCAST, StepKind.PREPARE_QUESTION_INPUT); }
                return list(StepKind.CONTINUE_WHILE_PLAYING);
            case WAIT_CONTINUE:
                if (cont) { phase = Phase.LISTENING; return list(StepKind.CONTINUE_DETECTED, StepKind.RESUME); }
                return list(StepKind.WAKE_WHILE_PAUSED);
            default: return list(StepKind.IGNORED_BUSY);
        }
    }

    public List<StepKind> onInputReady() {
        if (phase != Phase.ARMING) return Collections.emptyList();
        phase = Phase.ASKING;
        return list(StepKind.START_CAPTURE);
    }

    public List<StepKind> onQuestionDone() {
        if (phase != Phase.ASKING) return Collections.emptyList();
        phase = Phase.ANSWERING;
        return list(StepKind.ANSWER);
    }

    public List<StepKind> onAnswerDone() {
        if (phase != Phase.ANSWERING) return Collections.emptyList();
        phase = Phase.WAIT_CONTINUE;
        return list(StepKind.LISTEN_FOR_CONTINUE);
    }

    public List<StepKind> onEarbudTap() {
        switch (phase) {
            case LISTENING: return list(StepKind.MISSED_WAKE);
            case ASKING: return list(StepKind.STOP_CAPTURE);
            case WAIT_CONTINUE: phase = Phase.LISTENING; return list(StepKind.MISSED_CONTINUE, StepKind.RESUME);
            default: return Collections.emptyList();
        }
    }

    private static List<StepKind> list(StepKind... s) { return Arrays.asList(s); }
}
