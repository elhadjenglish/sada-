package app.sada.poc

// Stage 0 decision logic, kept free of Android classes so it can be unit-tested in CI.
enum class Phase { STOPPED, LISTENING, ANSWERING, WAIT_CONTINUE }

enum class StepKind {
    WAKE_DETECTED,           // "Hey Sada" while the podcast plays
    PAUSE_AND_ANSWER,        // pause now, then speak the test response
    LISTEN_FOR_CONTINUE,     // response finished; wait for "Continue"
    CONTINUE_DETECTED,       // "Continue" while paused
    RESUME,                  // resume at the saved position
    CONTINUE_WHILE_PLAYING,  // "Continue" heard while playing: a false trigger by definition
    IGNORED_WHILE_SPEAKING,  // anything heard while Sada speaks is ignored
    WAKE_WHILE_PAUSED,       // "Hey Sada" while already paused
    MISSED_WAKE,             // earbud tap while playing = "I said Hey Sada, nothing happened"
    MISSED_CONTINUE,         // earbud tap while paused = "I said Continue, nothing happened" (also resumes)
    UNKNOWN_KEYWORD,
}

class PocStateMachine {
    var phase: Phase = Phase.STOPPED
        private set

    fun start() { phase = Phase.LISTENING }
    fun stop() { phase = Phase.STOPPED }

    fun onKeyword(label: String): List<StepKind> {
        val l = label.trim().uppercase()
        val isWake = l.startsWith("HEY_SADA")
        val isContinue = l.startsWith("CONTINUE")
        if (!isWake && !isContinue) return listOf(StepKind.UNKNOWN_KEYWORD)
        return when (phase) {
            Phase.STOPPED -> emptyList()
            Phase.LISTENING ->
                if (isWake) {
                    phase = Phase.ANSWERING
                    listOf(StepKind.WAKE_DETECTED, StepKind.PAUSE_AND_ANSWER)
                } else {
                    listOf(StepKind.CONTINUE_WHILE_PLAYING)
                }
            Phase.ANSWERING -> listOf(StepKind.IGNORED_WHILE_SPEAKING)
            Phase.WAIT_CONTINUE ->
                if (isContinue) {
                    phase = Phase.LISTENING
                    listOf(StepKind.CONTINUE_DETECTED, StepKind.RESUME)
                } else {
                    listOf(StepKind.WAKE_WHILE_PAUSED)
                }
        }
    }

    fun onAnswerDone(): List<StepKind> {
        if (phase != Phase.ANSWERING) return emptyList()
        phase = Phase.WAIT_CONTINUE
        return listOf(StepKind.LISTEN_FOR_CONTINUE)
    }

    fun onEarbudTap(): List<StepKind> = when (phase) {
        Phase.LISTENING -> listOf(StepKind.MISSED_WAKE)
        Phase.WAIT_CONTINUE -> {
            phase = Phase.LISTENING
            listOf(StepKind.MISSED_CONTINUE, StepKind.RESUME)
        }
        else -> emptyList()
    }
}
