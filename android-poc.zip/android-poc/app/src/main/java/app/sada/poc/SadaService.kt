package app.sada.poc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.KeyEvent
import java.io.File
import java.util.Locale

/**
 * Stage 0 foreground service: plays the test podcast, listens for "Hey Sada" / "Continue" offline,
 * speaks a fixed test response, and records diagnostics. It must be started while the app is on screen.
 */
class SadaService : Service() {
    companion object {
        const val ACTION_START = "app.sada.poc.START"
        const val ACTION_STOP = "app.sada.poc.STOP"
        const val ACTION_MARK_MISS = "app.sada.poc.MARK_MISS"
        const val EXTRA_SOURCE = "source"
        const val EXTRA_SENSITIVITY = "sensitivity"
        const val EXTRA_MIC_MODE = "micMode"
        const val EXTRA_PLAYBACK = "playback"
        private const val CHANNEL = "sada-stage0"
        private const val NOTIF_ID = 7
        const val RESPONSE = "I heard you. This is Sada's test answer. Say continue to keep listening."
    }

    private val main = Handler(Looper.getMainLooper())
    private val machine = PocStateMachine()
    private lateinit var audio: AudioManager
    private var player: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var session: MediaSession? = null
    private var engine: KwsEngine? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var focus: AudioFocusRequest? = null
    private var tone: ToneGenerator? = null
    private var recordingCallback: AudioManager.AudioRecordingCallback? = null
    private var savedPositionMs = 0
    private var wakeAtMs = 0L
    private var continueAtMs = 0L
    private var started = false

    private val mediaAttrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Diag.init(this)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopEverything("Stopped from the notification or app"); return START_NOT_STICKY }
            ACTION_MARK_MISS -> { onEarbudTap("screen button"); return START_NOT_STICKY }
        }
        if (!goForeground()) { stopSelf(); return START_NOT_STICKY }
        if (!started) {
            val source = intent?.getStringExtra(EXTRA_SOURCE)
            val sensitivity = intent?.getStringExtra(EXTRA_SENSITIVITY) ?: "default"
            val micMode = intent?.getStringExtra(EXTRA_MIC_MODE) ?: "recognition"
            val playback = intent?.getBooleanExtra(EXTRA_PLAYBACK, true) ?: true
            if (playback && source == null) {
                Diag.log("error", "No podcast chosen")
                stopEverything("No source")
            } else {
                startEverything(source, sensitivity, micMode, playback)
            }
        }
        // Do not let Android restart the service on its own: a restarted service may not use the
        // microphone from the background, so it would only appear to work. The report shows the stop.
        return START_NOT_STICKY
    }

    private fun goForeground(): Boolean {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, SadaService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val notif: Notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Sada Stage 0 is listening")
            .setContentText("Say “Hey Sada”, then “Continue”. Everything stays on this phone.")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Stop test", stop).build())
            .build()
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(NOTIF_ID, notif)
            }
            true
        } catch (e: Exception) {
            Diag.log("error", "Could not start the foreground service: ${e.javaClass.simpleName}: ${e.message}")
            false
        }
    }

    private fun startEverything(source: String?, sensitivity: String, micMode: String, playback: Boolean) {
        started = true
        Diag.playback = playback
        Diag.checkLostSession(this)
        Diag.serviceRunning = true
        Diag.startedAt = System.currentTimeMillis()
        Diag.source = when {
            !playback -> "none (listen-only test)"
            source!!.startsWith("file:") -> "test episode (phone voice)"
            else -> "your audio file"
        }
        Diag.batteryAtStart = batteryPct()
        Diag.log("session-start", "Test started (${Diag.testMode} mode, sensitivity $sensitivity, mic $micMode, playback ${if (playback) "on" else "off"})")

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sada:stage0").also { it.acquire(6 * 60 * 60 * 1000L) }

        tone = try { ToneGenerator(AudioManager.STREAM_MUSIC, 70) } catch (_: Exception) { null }
        setUpTts()
        setUpMediaSession()
        watchRecording()

        val eng = KwsEngine(this) { label, at -> main.post { onKeyword(label, at) } }
        engine = eng
        if (!eng.start(sensitivity, micMode)) { stopEverything("Keyword engine or microphone failed"); return }

        if (!playback) {
            // Listen-only: no podcast, so nothing from the speaker can interfere with the microphone.
            machine.start()
            Diag.phase = machine.phase.name
            main.postDelayed({ refreshRoutes(log = true) }, 1500)
            main.post(heartbeat)
            return
        }
        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(mediaAttrs)
            mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setDataSource(this, Uri.parse(source!!)) // playback on ⇒ a source was required above
            mp.isLooping = true
            mp.setOnPreparedListener {
                requestFocus()
                it.start()
                machine.start()
                Diag.phase = machine.phase.name
                setPlaying(true)
                main.postDelayed({ refreshRoutes(log = true) }, 1500)
            }
            mp.setOnErrorListener { _, what, extra -> Diag.log("error", "Player error $what/$extra"); true }
            mp.prepareAsync()
        } catch (e: Exception) {
            Diag.log("error", "Could not open the audio: ${e.message}")
            stopEverything("Audio failed")
            return
        }
        main.post(heartbeat)
    }

    // ---- keyword handling ----

    private fun onKeyword(label: String, atMs: Long) {
        val steps = machine.onKeyword(label)
        if (steps.isEmpty()) Diag.log("ignored", "Heard $label before the test was ready (state ${machine.phase})")
        for (step in steps) execute(step, atMs, label)
        Diag.phase = machine.phase.name
    }

    private fun onEarbudTap(how: String) {
        val steps = machine.onEarbudTap()
        for (step in steps) execute(step, System.currentTimeMillis(), how)
        Diag.phase = machine.phase.name
    }

    private fun execute(step: StepKind, atMs: Long, label: String) {
        val mp = player
        when (step) {
            StepKind.WAKE_DETECTED -> wakeAtMs = atMs
            StepKind.PAUSE_AND_ANSWER -> {
                if (mp != null && mp.isPlaying) { mp.pause(); savedPositionMs = mp.currentPosition }
                val pauseMs = System.currentTimeMillis() - wakeAtMs
                val e = Diag.log("wake", "Heard $label → paused at ${savedPositionMs / 1000.0}s", pauseMs)
                if (Diag.testMode == "silence") Diag.setFalse(e.t, true)
                setPlaying(false)
                engine?.muted = true
                tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
                main.postDelayed({ speak() }, 250)
            }
            StepKind.LISTEN_FOR_CONTINUE -> {
                engine?.flushAfterSpeaking()
                main.postDelayed({ engine?.muted = false }, 300)
                Diag.log("waiting", "Waiting for “Continue”")
            }
            StepKind.CONTINUE_DETECTED -> continueAtMs = atMs
            StepKind.RESUME -> resume(label)
            StepKind.CONTINUE_WHILE_PLAYING -> Diag.log("continue-while-playing", "Heard $label while the podcast was playing (false trigger)")
            StepKind.IGNORED_WHILE_SPEAKING -> Diag.log("ignored", "Heard $label while Sada was speaking")
            StepKind.WAKE_WHILE_PAUSED -> Diag.log("wake-while-paused", "Heard $label while paused; say Continue")
            StepKind.MISSED_WAKE -> Diag.log("miss-wake", "You marked a missed “Hey Sada” ($label)")
            StepKind.MISSED_CONTINUE -> { continueAtMs = atMs; Diag.log("miss-continue", "You marked a missed “Continue” ($label); resuming") }
            StepKind.UNKNOWN_KEYWORD -> Diag.log("unknown", "Unexpected keyword $label")
        }
    }

    private fun resume(label: String) {
        val mp = player
        if (mp == null) {
            // Listen-only test: nothing to resume, but the timing and detection still count.
            val ms = System.currentTimeMillis() - continueAtMs
            if (label != "screen button" && label != "earbud") Diag.log("continue", "Heard $label (listen-only: no playback to resume)", ms)
            else Diag.log("resumed", "Resumed by tap (listen-only)", ms)
            return
        }
        mp.seekTo(savedPositionMs)
        requestFocus()
        mp.start()
        setPlaying(true)
        val resumeMs = System.currentTimeMillis() - continueAtMs
        if (label != "screen button" && label != "earbud") Diag.log("continue", "Heard $label → playing again", resumeMs)
        else Diag.log("resumed", "Resumed by tap", resumeMs)
        main.postDelayed({
            val drift = mp.currentPosition - savedPositionMs
            Diag.log("resume-drift", "Position after resume vs paused (includes ~0.3 s of playback)", drift.toLong())
        }, 300)
    }

    // ---- spoken response ----

    private fun setUpTts() {
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setLanguage(Locale.US)
                tts?.setAudioAttributes(mediaAttrs)
            }
            Diag.log(if (ttsReady) "tts" else "error", if (ttsReady) "Phone voice ready" else "Phone voice (text-to-speech) not available")
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                main.post { Diag.log("answer-start", "Speaking the test response", System.currentTimeMillis() - wakeAtMs) }
            }
            override fun onDone(utteranceId: String?) { main.post { answerDone() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { main.post { Diag.log("error", "Phone voice failed"); answerDone() } }
        })
    }

    private fun speak() {
        val t = tts
        if (t == null || !ttsReady) { Diag.log("error", "No phone voice; skipping the spoken response"); answerDone(); return }
        t.speak(RESPONSE, TextToSpeech.QUEUE_FLUSH, null, "answer-${SystemClock.elapsedRealtime()}")
    }

    private fun answerDone() {
        for (step in machine.onAnswerDone()) execute(step, System.currentTimeMillis(), "")
        Diag.phase = machine.phase.name
    }

    // ---- earbud button: marks misses (and resumes when paused) ----

    private fun setUpMediaSession() {
        val ms = MediaSession(this, "SadaStage0")
        ms.setCallback(object : MediaSession.Callback() {
            override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                @Suppress("DEPRECATION")
                val ev = mediaButtonIntent.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT)
                if (ev != null && ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                    Diag.log("button", "Earbud/media button ${KeyEvent.keyCodeToString(ev.keyCode)}")
                    onEarbudTap("earbud")
                }
                return true
            }
        })
        ms.isActive = true
        session = ms
    }

    private fun setPlaying(playing: Boolean) {
        val state = PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE)
            .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, (player?.currentPosition ?: 0).toLong(), 1f)
            .build()
        session?.setPlaybackState(state)
    }

    // ---- audio focus, routing, recording health ----

    private fun requestFocus() {
        val req = focus ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(mediaAttrs)
            .setOnAudioFocusChangeListener({ change ->
                Diag.log("focus", "Audio focus change $change (another app or a call took the audio)")
                if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                    if (machine.phase == Phase.LISTENING) { player?.pause(); setPlaying(false) }
                }
            }, main)
            .build()
        focus = req
        audio.requestAudioFocus(req)
    }

    private fun watchRecording() {
        if (Build.VERSION.SDK_INT < 29) return
        val cb = object : AudioManager.AudioRecordingCallback() {
            override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>) {
                val silenced = configs.any { it.isClientSilenced }
                if (silenced != Diag.micSilenced) {
                    Diag.micSilenced = silenced
                    Diag.log(if (silenced) "error" else "route", if (silenced) "Android silenced Sada's microphone (another app took it)" else "Microphone available again")
                }
                engine?.updateRoute()
            }
        }
        audio.registerAudioRecordingCallback(cb, main)
        recordingCallback = cb
    }

    @Suppress("DEPRECATION")
    private fun refreshRoutes(log: Boolean) {
        engine?.updateRoute()
        Diag.playbackRoute = AudioNames.describe(player?.routedDevice)
        Diag.audioMode = when (audio.mode) {
            AudioManager.MODE_NORMAL -> "normal (media)"
            AudioManager.MODE_IN_COMMUNICATION -> "IN COMMUNICATION (call mode)"
            AudioManager.MODE_IN_CALL -> "IN CALL"
            else -> "mode ${audio.mode}"
        }
        Diag.scoOn = audio.isBluetoothScoOn
        if (log) Diag.log("route", "Mic: ${Diag.micRoute} | Playback: ${Diag.playbackRoute} | Mode: ${Diag.audioMode} | SCO: ${Diag.scoOn}")
    }

    // ---- heartbeat: service health, battery, kill detection ----

    private val heartbeat = object : Runnable {
        var ticks = 0
        override fun run() {
            if (!Diag.serviceRunning) return
            ticks++
            val now = System.currentTimeMillis()
            Diag.lastHeartbeat = now
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val wasOn = Diag.screenOn
            Diag.screenOn = pm.isInteractive
            if (wasOn != Diag.screenOn) Diag.log("screen", if (Diag.screenOn) "Screen on" else "Screen off / locked")
            Diag.batteryPct = batteryPct()
            Diag.ignoringBatteryOpt = pm.isIgnoringBatteryOptimizations(packageName)
            val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            Diag.standbyBucket = when (um.appStandbyBucket) {
                UsageStatsManager.STANDBY_BUCKET_ACTIVE -> "active"
                UsageStatsManager.STANDBY_BUCKET_WORKING_SET -> "working set"
                UsageStatsManager.STANDBY_BUCKET_FREQUENT -> "frequent"
                UsageStatsManager.STANDBY_BUCKET_RARE -> "rare"
                UsageStatsManager.STANDBY_BUCKET_RESTRICTED -> "RESTRICTED"
                else -> "${um.appStandbyBucket}"
            }
            val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            Diag.bgRestricted = am.isBackgroundRestricted
            val before = "${Diag.micRoute}|${Diag.playbackRoute}|${Diag.audioMode}|${Diag.scoOn}"
            refreshRoutes(log = false)
            val after = "${Diag.micRoute}|${Diag.playbackRoute}|${Diag.audioMode}|${Diag.scoOn}"
            if (before != after) Diag.log("route", "Changed → Mic: ${Diag.micRoute} | Playback: ${Diag.playbackRoute} | Mode: ${Diag.audioMode} | SCO: ${Diag.scoOn}")
            try { File(filesDir, "heartbeat.txt").writeText("running\t$now\t${Diag.startedAt}") } catch (_: Exception) {}
            if (ticks % 60 == 0) Diag.log("alive", "Still running; battery ${Diag.batteryPct}%")
            main.postDelayed(this, 5000)
        }
    }

    private fun batteryPct(): Int {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    // ---- shutdown ----

    private fun stopEverything(reason: String) {
        main.removeCallbacksAndMessages(null)
        engine?.stop(); engine = null
        player?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
        player = null
        tts?.shutdown(); tts = null
        session?.release(); session = null
        tone?.release(); tone = null
        focus?.let { audio.abandonAudioFocusRequest(it) }
        recordingCallback?.let { audio.unregisterAudioRecordingCallback(it) }
        recordingCallback = null
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        machine.stop()
        Diag.phase = machine.phase.name
        if (Diag.serviceRunning) Diag.log("session-stop", reason)
        Diag.serviceRunning = false
        try { File(filesDir, "heartbeat.txt").writeText("stopped\t${System.currentTimeMillis()}\t0") } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        started = false
    }

    override fun onDestroy() {
        if (Diag.serviceRunning) stopEverything("Service destroyed")
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        Diag.log("info", "App swiped away from recent apps; the service keeps running")
        super.onTaskRemoved(rootIntent)
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Sada listening test", NotificationManager.IMPORTANCE_LOW))
    }
}
