package app.sada.poc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.media.ToneGenerator
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.KeyEvent
import app.sada.poc.PocStateMachine.Phase
import app.sada.poc.PocStateMachine.StepKind
import app.sada.poc.dsp.FrontEnd
import app.sada.poc.dsp.ReferenceBuffer
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Stage 0 foreground service: the whole hands-free cycle on the phone, offline.
 *   podcast (own player) → phone mic → echo cancellation when on the speaker → "Hey Sada" → pause →
 *   best microphone for the question (earbud mic if available) → record until the user stops →
 *   replay what was heard (no AI in Stage 0) → "Continue" → resume at the exact position.
 * Must be started while the app is on screen (Android rule for background microphone use).
 */
class SadaService : Service() {
    companion object {
        const val ACTION_START = "app.sada.poc.START"
        const val ACTION_STOP = "app.sada.poc.STOP"
        const val ACTION_MARK_MISS = "app.sada.poc.MARK_MISS"
        const val ACTION_RECORD_CHECK = "app.sada.poc.RECORD_CHECK"
        const val EXTRA_SOURCE = "source"
        const val EXTRA_SENSITIVITY = "sensitivity"
        const val EXTRA_MIC_MODE = "micMode"
        const val EXTRA_PLAYBACK = "playback"
        const val EXTRA_AEC = "aec"
        const val EXTRA_EARBUD_MIC = "earbudMic"
        private const val CHANNEL = "sada-stage0"
        private const val NOTIF_ID = 7
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val machine = PocStateMachine()
    private lateinit var audio: AudioManager
    private val reference = ReferenceBuffer(SAMPLE_RATE * 4)
    private val frontEnd = FrontEnd(reference)
    private var player: PodcastPlayer? = null
    private var input: AudioInput? = null
    private var detector: WakeDetector? = null
    @Volatile private var capture: QuestionCapture? = null
    @Volatile private var captureOnPhoneMic = false
    private var captureInput = "-"
    private var captureSetupMs = 0L
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private val ttsDone = ConcurrentHashMap<String, CountDownLatch>()
    private var session: MediaSession? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var focus: AudioFocusRequest? = null
    private var recordingCallback: AudioManager.AudioRecordingCallback? = null
    private var wakeAtMs = 0L
    private var continueAtMs = 0L
    private var savedPositionMs = 0L
    private var earbudMic = true
    private var started = false
    private var phaseSince = SystemClock.elapsedRealtime()
    private var lastPhase = ""

    /** Publishes the current phase and remembers when it started (for the stall watchdog). */
    private fun syncPhase() {
        val p = machine.phase.name
        if (p != lastPhase) { lastPhase = p; phaseSince = SystemClock.elapsedRealtime() }
        Diag.phase = p
    }
    @Volatile private var alive = false

    private val mediaAttrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Diag.init(this)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopEverything("Stopped from the notification or app"); return START_NOT_STICKY }
            ACTION_MARK_MISS -> { onEarbudTap("screen button"); return START_NOT_STICKY }
            ACTION_RECORD_CHECK -> { startMicCheck(); return START_NOT_STICKY }
        }
        if (!goForeground()) { stopSelf(); return START_NOT_STICKY }
        if (!started) {
            val source = intent?.getStringExtra(EXTRA_SOURCE)
            val playback = intent?.getBooleanExtra(EXTRA_PLAYBACK, true) ?: true
            if (playback && source == null) {
                Diag.log("error", "No podcast chosen"); stopEverything("No source")
            } else {
                startEverything(
                    source, playback,
                    intent?.getStringExtra(EXTRA_SENSITIVITY) ?: "default",
                    intent?.getStringExtra(EXTRA_MIC_MODE) ?: "recognition",
                    intent?.getBooleanExtra(EXTRA_AEC, true) ?: true,
                    intent?.getBooleanExtra(EXTRA_EARBUD_MIC, true) ?: true,
                )
            }
        }
        // Never restarted by Android on its own: a restarted service may not use the microphone from the background.
        return START_NOT_STICKY
    }

    private fun goForeground(): Boolean {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, SadaService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val notif: Notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Sada Stage 0 is listening")
            .setContentText("Say “Hey Sada”, ask, then “Continue”. Everything stays on this phone.")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Stop test", stop).build())
            .build()
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else startForeground(NOTIF_ID, notif)
            true
        } catch (e: Exception) {
            Diag.log("error", "Could not start the foreground service: ${e.javaClass.simpleName}: ${e.message}")
            false
        }
    }

    // ---------------- start / stop ----------------

    private fun startEverything(source: String?, playback: Boolean, sensitivity: String, micMode: String, aec: Boolean, earbud: Boolean) {
        started = true
        alive = true
        earbudMic = earbud
        Diag.checkLostSession(this)
        Diag.serviceRunning = true
        Diag.startedAt = System.currentTimeMillis()
        Diag.playback = playback
        Diag.aecWanted = aec
        Diag.earbudMicWanted = earbud
        Diag.source = when {
            !playback -> "none (listen-only test)"
            source!!.startsWith("file:") -> "test episode (phone voice)"
            else -> "your audio file"
        }
        Diag.batteryAtStart = batteryPct()
        Diag.resetInputCounters()
        Diag.log("session-start", "Test started (${Diag.testMode}; playback ${if (playback) "on" else "off"}; echo cancellation ${if (aec) "on" else "off"}; " +
            "earbud mic for questions ${if (earbud) "on" else "off"}; mic $micMode; sensitivity $sensitivity)")

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sada:stage0").also { it.acquire(6 * 60 * 60 * 1000L) }
        setUpTts()
        setUpMediaSession()
        watchRecording()

        MicCheck.deleteOlderThanHours(this, 24)
        AudioRouteGuard.repairIfNeeded(audio, "At test start")
        Diag.log("route", "At start: ${AudioRouteGuard.describe(audio)}")
        val det = WakeDetector(this)
        if (!det.load(sensitivity)) { stopEverything("Keyword model failed to load"); return }
        detector = det

        if (playback) {
            val p = PodcastPlayer(this, Uri.parse(source!!), mediaAttrs, reference) { kind, text -> Diag.log(kind, text) }
            player = p
            requestFocus()
            p.start()
            setPlaying(true)
        }
        val inp = AudioInput(this, frontEnd, { player }) { m, a, mName, aName -> onMicBlock(m, a, mName, aName) }
        inp.aecAllowed = aec
        input = inp
        if (!inp.start(micMode)) { stopEverything("Phone microphone failed"); return }
        machine.start()
        syncPhase()
        Diag.earbudMicStatus = earbudMicState()
        main.postDelayed({ refreshRoutes(log = true) }, 2000)
        main.post(heartbeat)
    }

    private fun stopEverything(reason: String) {
        alive = false
        main.removeCallbacksAndMessages(null)
        capture?.finishNow()
        input?.stop(); input = null
        player?.stop(); player = null
        // Always withdraw our call-mode request, whatever state the question flow was in (it only affects this app).
        AudioRouteGuard.release(audio)
        tts?.shutdown(); tts = null
        session?.release(); session = null
        focus?.let { audio.abandonAudioFocusRequest(it) }
        recordingCallback?.let { audio.unregisterAudioRecordingCallback(it) }
        recordingCallback = null
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        machine.stop()
        syncPhase()
        if (Diag.serviceRunning) Diag.log("session-stop", reason)
        Diag.serviceRunning = false
        try { File(filesDir, "heartbeat.txt").writeText("stopped\t${System.currentTimeMillis()}\t0") } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        started = false
    }

    override fun onDestroy() {
        if (Diag.serviceRunning) stopEverything("Service destroyed")
        worker.shutdownNow()
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        Diag.log("info", "App swiped away from recent apps; the service keeps running")
        super.onTaskRemoved(rootIntent)
    }

    // ---------------- microphone blocks (mic thread) ----------------

    private fun onMicBlock(m: FloatArray, a: FloatArray, mName: String, aName: String) {
        val q = capture
        if (q != null && captureOnPhoneMic && !q.done) {
            if (q.push(m)) main.post { questionDone() }
        }
        val hits = detector?.process(m, a, mName, aName) ?: return
        for (h in hits) main.post { onKeyword(h) }
    }

    // ---------------- flow ----------------

    private fun onKeyword(h: WakeDetector.Hit) {
        val steps = machine.onKeyword(h.label)
        if (steps.isEmpty()) Diag.log("ignored", "Heard ${h.label} before the test was ready (state ${machine.phase})")
        for (s in steps) execute(s, h.atMs, h.label, h.stream)
        syncPhase()
    }

    private fun onEarbudTap(how: String) {
        for (s in machine.onEarbudTap()) execute(s, System.currentTimeMillis(), how, "")
        syncPhase()
    }

    private fun execute(step: StepKind, atMs: Long, label: String, stream: String) {
        when (step) {
            StepKind.WAKE_DETECTED -> wakeAtMs = atMs
            StepKind.PAUSE_PODCAST -> {
                detector?.muted = true
                val p = player
                if (p != null && p.isPlaying) { p.pause(); savedPositionMs = p.positionMs() }
                setPlaying(false)
                val e = Diag.log("wake", "Heard $label on $stream → paused at ${savedPositionMs / 1000.0}s", System.currentTimeMillis() - wakeAtMs)
                if (Diag.testMode == "silence") Diag.setFalse(e.t, true)
            }
            StepKind.PREPARE_QUESTION_INPUT -> prepareQuestionInput()
            StepKind.START_CAPTURE -> Diag.log("asking", "Recording the question ($captureInput)")
            StepKind.STOP_CAPTURE -> capture?.finishNow()
            StepKind.ANSWER -> answer()
            StepKind.LISTEN_FOR_CONTINUE -> {
                detector?.flushNow()
                main.postDelayed({ detector?.muted = false }, 300)
                Diag.log("waiting", "Waiting for “Continue”")
            }
            StepKind.CONTINUE_DETECTED -> continueAtMs = atMs
            StepKind.RESUME -> resume(label)
            StepKind.CONTINUE_WHILE_PLAYING -> Diag.log("continue-while-playing", "Heard $label on $stream while the podcast was playing (false trigger)")
            StepKind.IGNORED_BUSY -> Diag.log("ignored", "Heard $label while busy (${machine.phase})")
            StepKind.WAKE_WHILE_PAUSED -> Diag.log("wake-while-paused", "Heard $label while paused; say Continue")
            StepKind.MISSED_WAKE -> Diag.log("miss-wake", "You marked a missed “Hey Sada” ($label)")
            StepKind.MISSED_CONTINUE -> { continueAtMs = atMs; Diag.log("miss-continue", "You marked a missed “Continue” ($label); resuming") }
            StepKind.UNKNOWN_KEYWORD -> Diag.log("unknown", "Unexpected keyword $label")
            StepKind.RECOVERED -> {
                Diag.log("recovered", "A step stalled in ${lastPhase} for over 30 s; recovered (say Continue to resume)")
                capture?.finishNow()
                capture = null
                captureOnPhoneMic = false
                val inp = input
                worker.execute { finishEarbud(inp) }
            }
        }
    }

    private fun earbudMicState(): String {
        val dev = EarbudMic.device(audio)
        return when {
            Build.VERSION.SDK_INT < 31 -> "needs Android 12+"
            dev == null -> "no Bluetooth headset microphone connected"
            else -> "available: ${AudioNames.describe(dev)}"
        }
    }

    /** Picks the microphone for the question: the earbud mic when connected (much closer to the mouth), else the phone mic. */
    private fun prepareQuestionInput() {
        val dev = if (earbudMic) EarbudMic.device(audio) else null
        Diag.earbudMicStatus = earbudMicState()
        if (dev == null) { startPhoneCapture(if (earbudMic) "phone mic (no earbud mic connected)" else "phone mic"); return }
        val inp = input
        worker.execute {
            var handedOver = false
            try {
                inp?.pauseCapture()
                SystemClock.sleep(120)
                val ms = if (alive) EarbudMic.connect(audio, dev, 4000) else -1
                if (!alive) return@execute
                if (ms < 0) {
                    main.post {
                        Diag.log("error", "Earbud microphone did not become active within 4 s; using the phone mic")
                        if (alive) startPhoneCapture("phone mic (earbud mic failed)")
                    }
                } else {
                    handedOver = true // startEarbudCapture now owns the call-mode request and will release it
                    main.post { if (alive) startEarbudCapture(ms) else worker.execute { finishEarbud(inp) } }
                }
            } catch (e: Throwable) {
                Diag.log("error", "Switching to the earbud mic failed: ${e.javaClass.simpleName}: ${e.message}")
                main.post { if (alive) startPhoneCapture("phone mic (earbud switch error)") }
            } finally {
                if (!handedOver) finishEarbud(inp)
            }
        }
    }

    /** Ends earbud-mic use: withdraws call mode, waits until Android has really applied it, then reopens the phone mic. */
    private fun finishEarbud(inp: AudioInput?) {
        val clean = AudioRouteGuard.releaseAndWait(audio, 2000)
        if (!clean) Diag.log("route-repair", "After the earbud mic: state not clean yet: ${AudioRouteGuard.describe(audio)}")
        SystemClock.sleep(500) // let Bluetooth return to music quality before anything is played
        inp?.resumeCapture()
    }

    private fun startPhoneCapture(label: String) {
        captureInput = label
        captureSetupMs = 0
        capture = QuestionCapture().also { it.skipFirst(350) }
        captureOnPhoneMic = true
        tone(AudioManager.STREAM_MUSIC)
        for (s in machine.onInputReady()) execute(s, System.currentTimeMillis(), "", "")
        syncPhase()
    }

    private fun startEarbudCapture(setupMs: Long) {
        captureInput = "earbud mic"
        captureSetupMs = setupMs
        val q = QuestionCapture().also { it.skipFirst(300) }
        capture = q
        captureOnPhoneMic = false
        tone(AudioManager.STREAM_VOICE_CALL)
        for (s in machine.onInputReady()) execute(s, System.currentTimeMillis(), "", "")
        syncPhase()
        val inp = input
        worker.execute {
            try {
                val ok = EarbudMic.record(q) { !alive }
                if (!ok) Diag.log("error", "Earbud microphone recording failed")
            } catch (e: Throwable) {
                Diag.log("error", "Earbud recording error: ${e.javaClass.simpleName}")
            } finally {
                q.finishNow()
                finishEarbud(inp)
                main.post { questionDone() }
            }
        }
    }

    /** Consented 10-second recording of what the microphone and detector receive (started from the app). */
    private fun startMicCheck() {
        val inp = input
        if (inp == null || !alive) { Diag.recordingCheck = "start a test first"; return }
        val rec = MicCheck.Recorder()
        Diag.recordingCheck = "recording 10 s…"
        Diag.log("mic-check", "Recording 10 s for the microphone check (stored only on this phone)")
        inp.tap = { raw, det ->
            if (rec.add(raw, det)) {
                inp.tap = null
                worker.execute {
                    val stamp = try { MicCheck.save(this, rec) } catch (e: Exception) { "not saved" }
                    Diag.recordingCheck = "analysing…"
                    val result = MicCheck.analyse(this, rec)
                    Diag.recordingCheck = "$result (recording $stamp)"
                    Diag.log("mic-check", result)
                }
            }
        }
    }

    private fun questionDone() {
        val q = capture ?: return
        if (machine.phase != Phase.ASKING) return
        captureOnPhoneMic = false
        val summary = q.summary(captureInput, captureSetupMs)
        Diag.lastQuestion = summary
        Diag.log("question", summary, if (q.heardSpeech) q.speech().size * 1000L / SAMPLE_RATE else 0L)
        for (s in machine.onQuestionDone()) execute(s, System.currentTimeMillis(), "", "")
        syncPhase()
    }

    /** Stage 0 "answer": play back what was heard, so you can judge the capture yourself. */
    private fun answer() {
        val q = capture
        capture = null
        worker.execute {
            try {
                if (q != null && q.heardSpeech) {
                    speakAndWait("Here is what I heard.", first = true)
                    Replay.play(q.speech(), mediaAttrs)
                    speakAndWait("Say continue to keep listening.", first = false)
                } else {
                    speakAndWait("I didn't hear a question. Say continue to keep listening.", first = true)
                }
            } catch (e: Throwable) {
                Diag.log("error", "Answer step failed: ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                main.post {
                    for (s in machine.onAnswerDone()) execute(s, System.currentTimeMillis(), "", "")
                    syncPhase()
                }
            }
        }
    }

    private fun resume(label: String) {
        val ms = System.currentTimeMillis() - continueAtMs
        val p = player
        if (p == null) {
            if (label == "earbud" || label == "screen button") Diag.log("resumed", "Resumed by tap (listen-only)", ms)
            else Diag.log("continue", "Heard $label (listen-only: no playback to resume)", ms)
            return
        }
        requestFocus()
        p.play()
        setPlaying(true)
        if (label == "earbud" || label == "screen button") Diag.log("resumed", "Resumed by tap", ms)
        else Diag.log("continue", "Heard $label → playing again", ms)
        main.postDelayed({
            Diag.log("resume-drift", "Position after resume vs paused (includes ~0.5 s of playback)", p.positionMs() - savedPositionMs)
        }, 500)
    }

    private fun tone(stream: Int) {
        try {
            val t = ToneGenerator(stream, 70)
            t.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            main.postDelayed({ t.release() }, 400)
        } catch (_: Exception) {}
    }

    // ---------------- speech ----------------

    private fun setUpTts() {
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) { tts?.setLanguage(Locale.US); tts?.setAudioAttributes(mediaAttrs) }
            Diag.log(if (ttsReady) "tts" else "error", if (ttsReady) "Phone voice ready" else "Phone voice (text-to-speech) not available")
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                if (utteranceId?.startsWith("first-") == true) Diag.log("answer-start", "Speaking", System.currentTimeMillis() - wakeAtMs)
            }
            override fun onDone(utteranceId: String?) { utteranceId?.let { ttsDone.remove(it)?.countDown() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { utteranceId?.let { ttsDone.remove(it)?.countDown() } }
        })
    }

    /** Speaks and waits until finished (worker thread only). */
    private fun speakAndWait(text: String, first: Boolean) {
        val t = tts
        if (t == null || !ttsReady) { Diag.log("error", "No phone voice; skipped: $text"); return }
        val id = (if (first) "first-" else "next-") + SystemClock.elapsedRealtime()
        val latch = CountDownLatch(1)
        ttsDone[id] = latch
        t.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), id)
        latch.await(15, TimeUnit.SECONDS)
    }

    // ---------------- earbud button ----------------

    private fun setUpMediaSession() {
        val ms = MediaSession(this, "SadaStage0")
        ms.setCallback(object : MediaSession.Callback() {
            override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                @Suppress("DEPRECATION")
                val ev = mediaButtonIntent.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT)
                if (ev != null && ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                    Diag.log("button", "Earbud/media button ${KeyEvent.keyCodeToString(ev.keyCode)}")
                    onEarbudTap("earbud")
                }
                return true
            }
        })
        ms.isActive = true
        session = ms
    }

    private fun setPlaying(playing: Boolean) {
        val state = PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE)
            .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, player?.positionMs() ?: 0L, 1f)
            .build()
        session?.setPlaybackState(state)
    }

    // ---------------- audio focus, routing, recording health ----------------

    private fun requestFocus() {
        val req = focus ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(mediaAttrs)
            .setOnAudioFocusChangeListener({ change ->
                Diag.log("focus", "Audio focus change $change (another app or a call took the audio)")
                if ((change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) && machine.phase == Phase.LISTENING) {
                    player?.pause(); setPlaying(false)
                }
            }, main)
            .build()
        focus = req
        audio.requestAudioFocus(req)
    }

    private fun watchRecording() {
        if (Build.VERSION.SDK_INT < 29) return
        val cb = object : AudioManager.AudioRecordingCallback() {
            override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>) {
                val silenced = configs.any { it.isClientSilenced }
                if (silenced != Diag.micSilenced) {
                    Diag.micSilenced = silenced
                    Diag.log(if (silenced) "error" else "route", if (silenced) "Android silenced Sada's microphone (another app took it)" else "Microphone available again")
                }
                input?.updateRoute()
            }
        }
        audio.registerAudioRecordingCallback(cb, main)
        recordingCallback = cb
    }

    @Suppress("DEPRECATION")
    private fun refreshRoutes(log: Boolean) {
        input?.updateRoute()
        Diag.playbackRoute = if (player == null) "none (listen-only)" else AudioNames.describe(player?.track?.routedDevice)
        Diag.audioMode = when (audio.mode) {
            AudioManager.MODE_NORMAL -> "normal (media)"
            AudioManager.MODE_IN_COMMUNICATION -> "IN COMMUNICATION (call mode)"
            AudioManager.MODE_IN_CALL -> "IN CALL"
            else -> "mode ${audio.mode}"
        }
        Diag.scoOn = audio.isBluetoothScoOn
        if (log) Diag.log("route", "Mic: ${Diag.micRoute} | Playback: ${Diag.playbackRoute} | Mode: ${Diag.audioMode} | SCO: ${Diag.scoOn}")
    }

    private val heartbeat = object : Runnable {
        var ticks = 0
        override fun run() {
            if (!Diag.serviceRunning) return
            ticks++
            val now = System.currentTimeMillis()
            Diag.lastHeartbeat = now
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val wasOn = Diag.screenOn
            Diag.screenOn = pm.isInteractive
            if (wasOn != Diag.screenOn) Diag.log("screen", if (Diag.screenOn) "Screen on" else "Screen off / locked")
            Diag.batteryPct = batteryPct()
            Diag.ignoringBatteryOpt = pm.isIgnoringBatteryOptimizations(packageName)
            val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            Diag.standbyBucket = when (um.appStandbyBucket) {
                UsageStatsManager.STANDBY_BUCKET_ACTIVE -> "active"
                UsageStatsManager.STANDBY_BUCKET_WORKING_SET -> "working set"
                UsageStatsManager.STANDBY_BUCKET_FREQUENT -> "frequent"
                UsageStatsManager.STANDBY_BUCKET_RARE -> "rare"
                UsageStatsManager.STANDBY_BUCKET_RESTRICTED -> "RESTRICTED"
                else -> "${um.appStandbyBucket}"
            }
            val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            Diag.bgRestricted = am.isBackgroundRestricted
            if (machine.phase == Phase.LISTENING) Diag.earbudMicStatus = earbudMicState()
            // No call mode should be active while listening for wake words or Continue.
            if (machine.phase == Phase.LISTENING || machine.phase == Phase.WAIT_CONTINUE) {
                if (!AudioRouteGuard.isClean(audio)) {
                    worker.execute {
                        if (AudioRouteGuard.repairIfNeeded(audio, "While listening")) input?.requestReopen("call mode was found active while listening")
                    }
                }
            }
            // Stall watchdog: preparing, asking or answering must never block listening for long.
            val busy = machine.phase == Phase.ARMING || machine.phase == Phase.ASKING || machine.phase == Phase.ANSWERING
            if (busy && SystemClock.elapsedRealtime() - phaseSince > 30_000) {
                for (s in machine.recover()) execute(s, System.currentTimeMillis(), "", "")
                syncPhase()
            }
            val before = "${Diag.micRoute}|${Diag.playbackRoute}|${Diag.audioMode}|${Diag.scoOn}"
            refreshRoutes(log = false)
            val after = "${Diag.micRoute}|${Diag.playbackRoute}|${Diag.audioMode}|${Diag.scoOn}"
            if (before != after) Diag.log("route", "Changed → Mic: ${Diag.micRoute} | Playback: ${Diag.playbackRoute} | Mode: ${Diag.audioMode} | SCO: ${Diag.scoOn}")
            try { File(filesDir, "heartbeat.txt").writeText("running\t$now\t${Diag.startedAt}") } catch (_: Exception) {}
            if (ticks % 60 == 0) Diag.log("alive", "Still running; battery ${Diag.batteryPct}%; ${Diag.aecText()}")
            main.postDelayed(this, 5000)
        }
    }

    private fun batteryPct(): Int {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Sada listening test", NotificationManager.IMPORTANCE_LOW))
    }
}
