package app.sada.poc

import android.content.Context
import com.k2fsa.sherpa.onnx.KeywordSpotter
import com.k2fsa.sherpa.onnx.OnlineStream

/**
 * Offline "Hey Sada" / "Continue" detection on the two processed microphone streams from the front end.
 * A keyword counts if either stream catches it (the stream is recorded for diagnostics). A third, very sensitive
 * stream on the main signal only logs near misses. Audio is never stored.
 */
class WakeDetector(private val ctx: Context) {
    private var kws: KeywordSpotter? = null
    private var main: OnlineStream? = null
    private var alt: OnlineStream? = null
    private var probe: OnlineStream? = null
    private val chunk = 1536 // 96 ms
    private val bufMain = FloatArray(chunk)
    private val bufAlt = FloatArray(chunk)
    private var fill = 0
    private var lastHit = 0L
    private var lastProbe = 0L
    @Volatile var muted = false
    @Volatile private var flush = false
    private var chunks = 0L
    private var totalMs = 0.0
    private var maxMs = 0.0

    data class Hit(val label: String, val stream: String, val atMs: Long)

    /** sensitivity: "default" uses the thresholds in keywords.txt; others adjust them (experimental). */
    fun load(sensitivity: String): Boolean {
        Kws.checkKeywords(ctx)
        return try {
            val k = kws ?: Kws.spotter(ctx, "$MODEL_DIR/keywords.txt").also { kws = it }
            val custom = customKeywords(sensitivity)
            main = if (custom == null) k.createStream() else k.createStream(custom)
            alt = if (custom == null) k.createStream() else k.createStream(custom)
            Diag.keywordsMode = if (custom == null) "built-in thresholds" else "sensitivity: $sensitivity (experimental)"
            Diag.modelStatus = "✓ model loaded ($MODEL_DIR)"
            Diag.log("model", Diag.modelStatus)
            probe = try {
                k.createStream(KeywordFile.withThreshold(Kws.readAssetLines(ctx, "$MODEL_DIR/keywords.txt"), 0.08).joinToString("/"))
                    .also { Diag.probeStatus = "on (threshold 0.08, logs only)" }
            } catch (e: Throwable) { Diag.probeStatus = "unavailable: ${e.javaClass.simpleName}"; null }
            true
        } catch (e: Throwable) {
            Diag.modelStatus = "✗ model failed to load: ${e.javaClass.simpleName}: ${e.message}"
            Diag.log("error", Diag.modelStatus)
            false
        }
    }

    /** Drops buffered audio and detector state (after Sada has spoken, or after a question). */
    fun flushNow() { flush = true }

    /**
     * Feeds one 256-sample block of each stream. Returns keywords detected (empty most of the time).
     * mainName/altName describe what the streams are right now (they differ with and without echo cancellation).
     */
    fun process(mainBlock: FloatArray, altBlock: FloatArray, mainName: String, altName: String): List<Hit> {
        val k = kws ?: return emptyList()
        val m = main ?: return emptyList()
        val a = alt ?: return emptyList()
        System.arraycopy(mainBlock, 0, bufMain, fill, mainBlock.size)
        System.arraycopy(altBlock, 0, bufAlt, fill, altBlock.size)
        fill += mainBlock.size
        if (fill < chunk) return emptyList()
        fill = 0
        if (flush) { k.reset(m); k.reset(a); probe?.let { k.reset(it) }; flush = false }
        val t0 = System.nanoTime()
        val hitsMain = Kws.feed(k, m, bufMain.copyOf())
        val hitsAlt = Kws.feed(k, a, bufAlt.copyOf())
        val hitsProbe = probe?.let { p -> try { Kws.feed(k, p, bufMain.copyOf()) } catch (_: Throwable) { emptyList() } } ?: emptyList()
        val ms = (System.nanoTime() - t0) / 1e6
        chunks++; totalMs += ms; if (ms > maxMs) maxMs = ms
        if (chunks % 10 == 0L) { Diag.kwsChunkMsAvg = totalMs / chunks * (1600.0 / chunk); Diag.kwsChunkMsMax = maxMs }
        Diag.samplesFed += chunk
        Diag.buffersFed++

        val now = System.currentTimeMillis()
        val out = ArrayList<Hit>()
        // the same keyword from both streams within 1.5 s is one detection
        for ((label, stream) in hitsMain.map { it to mainName } + hitsAlt.map { it to altName }) {
            val dup = out.any { it.label == label } || now - lastHit < 1500
            Diag.log("kws-raw", "Detector reported $label on $stream${if (muted) " (ignored: busy)" else if (dup) " (same detection)" else ""}")
            if (!dup) { out.add(Hit(label, stream, now)); lastHit = now }
        }
        if (hitsMain.isNotEmpty() || hitsAlt.isNotEmpty() || hitsProbe.isNotEmpty()) Diag.noteDetectorOutput()
        if (hitsMain.isNotEmpty() || hitsAlt.isNotEmpty()) Diag.countStreamHit(if (hitsMain.isNotEmpty() && hitsAlt.isNotEmpty()) "both" else if (hitsMain.isNotEmpty()) mainName else altName)
        for (label in hitsProbe) {
            if (now - lastHit > 1500 && now - lastProbe > 1500) Diag.log("near-miss", "Almost detected $label (below the real threshold)")
            lastProbe = now
        }
        return if (muted) emptyList() else out
    }

    private fun customKeywords(sensitivity: String): String? {
        if (sensitivity == "default") return null
        val delta = if (sensitivity == "more") -0.08 else 0.08
        val lines = Kws.readAssetLines(ctx, "$MODEL_DIR/keywords.txt").filter { it.isNotBlank() }
        return lines.joinToString("/") { line ->
            val m = Regex("#([0-9.]+)").find(line)
            if (m != null) {
                val v = (m.groupValues[1].toDouble() + delta).coerceIn(0.05, 0.9)
                line.replace(m.value, "#" + String.format(java.util.Locale.US, "%.2f", v))
            } else line
        }
    }
}
