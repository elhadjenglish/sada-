package app.sada.poc

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTimestamp
import android.media.MediaRecorder
import android.os.SystemClock
import app.sada.poc.dsp.ClockAlign
import app.sada.poc.dsp.FrontEnd
import kotlin.math.max

/**
 * Phone-microphone capture for wake words (and questions without earbuds): 16 kHz mono blocks of 16 ms,
 * aligned with the podcast and processed by [FrontEnd]. Echo cancellation is on only while the podcast plays
 * through the phone speaker. Audio is never stored.
 */
class AudioInput(
    private val ctx: Context,
    private val frontEnd: FrontEnd,
    private val player: () -> PodcastPlayer?,
    private val onBlock: (main: FloatArray, alt: FloatArray, mainName: String, altName: String) -> Unit,
) {
    @Volatile private var running = false
    @Volatile private var paused = false
    @Volatile var aecAllowed = true          // user switch for A/B testing
    private var thread: Thread? = null
    private var record: AudioRecord? = null
    private val align = ClockAlign()
    @Volatile private var micMode = "recognition"

    fun start(mode: String): Boolean {
        micMode = mode
        if (!open()) return false
        running = true
        thread = Thread({ loop() }, "sada-mic").also { it.start() }
        return true
    }

    private fun open(): Boolean {
        val source = if (micMode == "plain") MediaRecorder.AudioSource.MIC else MediaRecorder.AudioSource.VOICE_RECOGNITION
        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufBytes = max(minBuf, SAMPLE_RATE * 2)
        val rec = try {
            AudioRecord(source, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufBytes)
        } catch (e: SecurityException) {
            Diag.log("error", "Microphone permission missing"); return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            Diag.log("error", "Phone microphone could not be opened (another app may be using it)"); rec.release(); return false
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }?.let {
            val ok = rec.setPreferredDevice(it)
            Diag.log("route", "Asked Android for the ${AudioNames.describe(it)}: ${if (ok) "accepted" else "refused"}")
        }
        rec.startRecording()
        if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            Diag.log("error", "Phone microphone did not start (state ${rec.recordingState})"); rec.release(); return false
        }
        record = rec
        Diag.micSource = if (micMode == "plain") "plain microphone (MIC)" else "speech recognition (VOICE_RECOGNITION)"
        Diag.micFormat = "${rec.sampleRate} Hz, ${rec.channelCount} channel(s), " +
            (if (rec.audioFormat == AudioFormat.ENCODING_PCM_16BIT) "PCM 16-bit" else "encoding ${rec.audioFormat}") + ", buffer $bufBytes bytes"
        Diag.log("mic", "Phone mic: ${Diag.micSource}; ${Diag.micFormat}")
        Diag.micRoute = AudioNames.describe(rec.routedDevice)
        align.reset()
        return true
    }

    private fun close() {
        try { record?.stop() } catch (_: Exception) {}
        record?.release()
        record = null
    }

    /** Releases the phone microphone (e.g. while the earbud microphone records a question). */
    fun pauseCapture() { paused = true }
    /** Re-opens the phone microphone after pauseCapture(). */
    fun resumeCapture() { paused = false }

    fun stop() {
        running = false
        try { thread?.join(1500) } catch (_: InterruptedException) {}
        thread = null
        close()
    }

    fun updateRoute() { record?.let { Diag.micRoute = AudioNames.describe(it.routedDevice) } }

    private fun loop() {
        val n = FrontEnd.BLOCK
        val pcm = ShortArray(n)
        val mic = FloatArray(n)
        val main = FloatArray(n)
        val alt = FloatArray(n)
        val recTs = AudioTimestamp()
        val playTs = AudioTimestamp()
        var micIndex = 0L
        var blocks = 0L
        var levelSum = 0.0
        var levelN = 0
        var offset = Double.NaN
        while (running) {
            if (paused) {
                if (record != null) { close(); Diag.log("mic", "Phone mic released (earbud mic in use)") }
                SystemClock.sleep(20); continue
            }
            if (record == null) {
                if (!open()) { SystemClock.sleep(500); continue }
                micIndex = 0; offset = Double.NaN
                Diag.log("mic", "Phone mic back")
            }
            val rec = record ?: continue
            var got = 0
            while (got < n && running && !paused) {
                val r = rec.read(pcm, got, n - got)
                if (r <= 0) { Diag.emptyReads++; Diag.lastReadCode = r; SystemClock.sleep(5); continue }
                got += r
            }
            if (got < n) continue
            val st = Pcm.stats(pcm, n)
            Diag.micLevelDb = st.rmsDb
            Diag.micPeak = max(Diag.micPeak * 0.995, st.peak)
            Diag.clippedSamples += st.clipped
            if (st.zeros == n) Diag.zeroBuffers++
            levelSum += st.rmsDb; levelN++
            if (levelN >= 60) { Diag.micLevelAvgDb = levelSum / levelN; levelSum = 0.0; levelN = 0 }
            for (i in 0 until n) mic[i] = pcm[i] / 32768f

            val p = player()
            val speaker = p != null && p.isPlaying && isSpeaker(p)
            frontEnd.setPodcastActive(p != null && p.isPlaying)
            frontEnd.setEchoCancellation(aecAllowed && speaker)
            // Align with the podcast about 8 times a second.
            if (speaker && p != null && blocks % 8 == 0L) {
                val pl: PodcastPlayer = p
                val haveRec = rec.getTimestamp(recTs, AudioTimestamp.TIMEBASE_MONOTONIC) == AudioRecord.SUCCESS
                val havePlay = haveRec && pl.timestamp(playTs)
                val raw = if (havePlay) {
                    Diag.alignMethod = "playback + recording timestamps"
                    ClockAlign.rawOffset(recTs.framePosition, recTs.nanoTime, playTs.framePosition, playTs.nanoTime, pl.sampleRate)
                } else {
                    // Fallback: what has been handed to the speaker vs what has been read from the mic, right now.
                    Diag.alignMethod = "fallback (no timestamps)"
                    val head = (pl.track?.playbackHeadPosition?.toLong() ?: 0L) and 0xffffffffL
                    head.toDouble() * SAMPLE_RATE / max(1, pl.sampleRate) - micIndex
                }
                offset = align.update(raw)
                Diag.alignOffsetMs = offset / 16.0
                Diag.alignResyncs = align.resyncs()
            }
            frontEnd.process(mic, micIndex, offset, main, alt)
            micIndex += n
            blocks++
            if (blocks % 30 == 0L) {
                val a = frontEnd.echoCanceller()
                Diag.aecOn = frontEnd.echoCancellationOn()
                Diag.aecErleDb = a.erleDb()
                Diag.aecDelayMs = a.peakTap() / 16.0 - FrontEnd.LEAD / 16.0
                Diag.aecDisturbed = a.doubleTalkFraction()
                Diag.aecCopies = a.copies()
                Diag.aecRealigns = frontEnd.realigns()
                Diag.aecMissingRef = frontEnd.missingReferenceBlocks()
                Diag.agcGainDb = frontEnd.agc().gainDb()
                Diag.noiseFloorDb = frontEnd.agc().noiseFloorDb()
            }
            val aecOn = frontEnd.echoCancellationOn()
            onBlock(main, alt, if (aecOn) "echo-cancelled+suppressed" else "gain-controlled", if (aecOn) "echo-cancelled" else "raw mic")
        }
    }

    private fun isSpeaker(p: PodcastPlayer): Boolean {
        val d = p.track?.routedDevice ?: return true // unknown: assume speaker (cancelling costs little)
        return d.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER || d.type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
    }
}
