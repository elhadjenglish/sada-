package app.sada.poc

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Stage 0 test screen. Plain Android views, no extra libraries. */
class MainActivity : Activity() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var events: TextView
    private lateinit var detections: LinearLayout
    private lateinit var startStop: Button
    private lateinit var attempts: EditText
    private lateinit var sourceLabel: TextView
    private lateinit var selfTestView: TextView
    @Volatile private var selfTestRunning = false
    private var shownDetections = -1
    private val prefs by lazy { getSharedPreferences("stage0", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Diag.init(this)
        Diag.checkLostSession(this)
        Diag.testMode = prefs.getString("mode", "walking") ?: "walking"
        buildUi()
    }

    override fun onResume() { super.onResume(); main.post(refresh) }
    override fun onPause() { super.onPause(); main.removeCallbacks(refresh) }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float = 15f, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; if (bold) setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(6), 0, dp(2))
    }
    private fun button(label: String, onClick: () -> Unit) = Button(this).apply { text = label; setAllCaps(false); setOnClickListener { onClick() } }

    private fun buildUi() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(32)) }
        col.addView(text("Sada · Stage 0 wake-word test", 21f, true))
        col.addView(text("Offline test: nothing is sent to the internet. Say “Hey Sada” to pause, then “Continue”.", 14f))

        col.addView(text("1. Set up (once)", 17f, true))
        col.addView(button("Allow microphone and notifications") { askPermissions() })
        col.addView(button("Let Sada run in the background (battery)") { askBatteryExemption() })
        col.addView(button("Open Sada's app settings (Infinix battery options)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        col.addView(text("2. Choose what to listen to", 17f, true))
        sourceLabel = text("", 14f)
        col.addView(sourceLabel)
        col.addView(button("Make the test episode (phone voice, ~1 min to prepare)") { makeTestEpisode() })
        col.addView(button("Or choose a podcast audio file on this phone") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*"), 42)
        })

        col.addView(text("3. Test type", 17f, true))
        val modes = RadioGroup(this)
        val walking = RadioButton(this).apply { id = View.generateViewId(); text = "Walking test: I will say “Hey Sada” and count my attempts" }
        val silence = RadioButton(this).apply { id = View.generateViewId(); text = "Silence test: I won't speak (every detection is false)" }
        modes.addView(walking); modes.addView(silence)
        modes.check(if (Diag.testMode == "silence") silence.id else walking.id)
        modes.setOnCheckedChangeListener { _, id -> Diag.testMode = if (id == silence.id) "silence" else "walking"; prefs.edit().putString("mode", Diag.testMode).apply() }
        col.addView(modes)

        col.addView(text("Sensitivity", 15f, true))
        val sens = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val opts = listOf("default" to "Default", "more" to "More sensitive", "fewer" to "Fewer false")
        val saved = prefs.getString("sens", "default")
        for ((key, label) in opts) {
            val rb = RadioButton(this).apply { id = View.generateViewId(); text = label; tag = key }
            sens.addView(rb)
            if (key == saved) sens.check(rb.id)
        }
        sens.setOnCheckedChangeListener { g, id -> prefs.edit().putString("sens", g.findViewById<RadioButton>(id).tag as String).apply() }
        col.addView(sens)
        col.addView(text("Changing sensitivity is experimental; start with Default.", 12f))

        col.addView(text("Microphone mode", 15f, true))
        val mic = RadioGroup(this)
        val savedMic = prefs.getString("mic", "recognition")
        for ((key, label) in listOf("recognition" to "Speech-recognition input (default)", "plain" to "Plain microphone (no processing)")) {
            val rb = RadioButton(this).apply { id = View.generateViewId(); text = label; tag = key }
            mic.addView(rb)
            if (key == savedMic) mic.check(rb.id)
        }
        mic.setOnCheckedChangeListener { g, id -> prefs.edit().putString("mic", g.findViewById<RadioButton>(id).tag as String).apply() }
        col.addView(mic)
        col.addView(CheckBox(this).apply {
            text = "Play the podcast during the test (untick for a listen-only test: nothing playing, so nothing can interfere)"
            isChecked = prefs.getBoolean("playback", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("playback", c).apply() }
        })

        col.addView(text("Detector self-test (no microphone)", 15f, true))
        col.addView(text("Checks the keywords, runs recorded speech through the detector and compares with the build machine, then feeds “Hey Sada” and “Continue” in the phone's voice. Takes about 30 seconds.", 12f))
        col.addView(button("Run detector self-test") { runSelfTest() })
        selfTestView = text(Diag.selfTest, 13f).apply { typeface = Typeface.MONOSPACE }
        col.addView(selfTestView)

        col.addView(text("4. Run", 17f, true))
        startStop = button("Start test") { toggle() }
        col.addView(startStop)
        col.addView(button("I said it but nothing happened (mark a miss)") { mark() })
        col.addView(text("With the phone in your pocket, a single tap on the earbud marks a miss instead. While paused, a tap also resumes.", 12f))

        col.addView(text("Live status", 17f, true))
        status = text("", 13f).apply { typeface = Typeface.MONOSPACE }
        col.addView(status)

        col.addView(text("Results", 17f, true))
        stats = text("", 13f).apply { typeface = Typeface.MONOSPACE }
        col.addView(stats)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text("Times I said “Hey Sada”: ", 14f))
        attempts = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER; setText(prefs.getString("attempts", "")); minEms = 3
            setOnFocusChangeListener { _, has -> if (!has) prefs.edit().putString("attempts", text.toString()).apply() }
        }
        row.addView(attempts)
        col.addView(row)
        col.addView(button("Copy report (to send to Claude)") { copyReport() })
        col.addView(button("Clear results") { Diag.reset(); prefs.edit().remove("attempts").apply(); attempts.setText(""); shownDetections = -1 })

        col.addView(text("Wake detections (tick the ones you did NOT say)", 15f, true))
        detections = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(detections)

        col.addView(text("Event log", 15f, true))
        events = text("", 12f).apply { typeface = Typeface.MONOSPACE }
        col.addView(events)

        setContentView(ScrollView(this).apply { addView(col) })
        updateSourceLabel()
    }

    private val refresh = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            val running = Diag.serviceRunning
            startStop.text = if (running) "Stop test" else "Start test"
            val up = if (running) (now - Diag.startedAt) / 1000 else 0
            val hb = if (Diag.lastHeartbeat > 0) (now - Diag.lastHeartbeat) / 1000 else -1
            status.text = buildString {
                append("Service: ${if (running) "RUNNING ${up / 60}m ${up % 60}s" else "stopped"} | state: ${Diag.phase}\n")
                if (running) append("Last heartbeat: ${hb}s ago | screen: ${if (Diag.screenOn) "on" else "off"}\n")
                append("Model: ${Diag.modelStatus}\n")
                append("Keywords: ${Diag.keywordCheck}\n")
                append("Microphone: ${Diag.micRoute}\n")
                append("Mic input: ${Diag.micSource}; ${Diag.micFormat}\n")
                append("Reached detector: ${"%.1f".format(Diag.samplesFed / 16000.0)} s of audio in ${Diag.buffersFed} buffers | empty reads ${Diag.emptyReads} | all-zero buffers ${Diag.zeroBuffers} | clipped ${Diag.clippedSamples} | peak ${"%.2f".format(Diag.micPeak)}\n")
                append("Near-miss listener: ${Diag.probeStatus}\n")
                append("Playback:   ${Diag.playbackRoute}\n")
                append("Audio mode: ${Diag.audioMode} | Bluetooth call audio (SCO): ${if (Diag.scoOn) "ON ⚠" else "off"}\n")
                append(routeVerdict())
                append("Mic level: ${"%.0f".format(Diag.micLevelDb)} dBFS (avg ${"%.0f".format(Diag.micLevelAvgDb)})${if (Diag.micSilenced) " — SILENCED by Android" else ""}\n")
                append("Keyword engine: ${"%.1f".format(Diag.kwsChunkMsAvg)} ms per 100 ms audio (max ${"%.0f".format(Diag.kwsChunkMsMax)})\n")
                append("Battery: ${Diag.batteryPct}% (start ${Diag.batteryAtStart}%) | optimization ignored: ${batteryExempt()}\n")
                append("Standby bucket: ${Diag.standbyBucket} | background restricted: ${Diag.bgRestricted}\n")
                append("Keywords: ${Diag.keywordsMode} | test: ${Diag.testMode}")
            }
            val st = Diag.stats()
            stats.text = buildString {
                append("Listening: ${"%.1f".format(st.listeningMinutes)} min | stopped by Android: ${st.unexpectedStops}\n")
                append("Wake detections: ${st.wakes} | marked false: ${st.wakesMarkedFalse}\n")
                val a = attempts.text.toString().toIntOrNull()
                if (a != null && a > 0) {
                    val hits = (st.wakes - st.wakesMarkedFalse).coerceAtLeast(0)
                    append("Detected ${hits} of $a attempts (${100 * hits / a}%) | missed ${(a - hits).coerceAtLeast(0)}\n")
                }
                append("Misses marked by tap: wake ${st.missedWake}, continue ${st.missedContinue}\n")
                append("“Continue” heard while playing (false): ${st.continueWhilePlaying}\n")
                append("Raw detector outputs: ${st.rawDetections} | near misses: ${st.nearMisses} | ignored: ${st.ignored}\n")
                append("Wake → paused: ${Diag.summarize(st.pauseMs)}\n")
                append("Wake → response: ${Diag.summarize(st.answerMs)}\n")
                append("Continue → playing: ${Diag.summarize(st.resumeMs)}")
            }
            val all = Diag.snapshot()
            val wakes = all.filter { it.kind == "wake" }
            if (wakes.size != shownDetections) {
                shownDetections = wakes.size
                detections.removeAllViews()
                for (w in wakes.takeLast(40).reversed()) {
                    detections.addView(CheckBox(this@MainActivity).apply {
                        text = "${Diag.time(w.t)}  ${w.text}"
                        isChecked = Diag.isFalse(w.t)
                        setOnCheckedChangeListener { _, c -> Diag.setFalse(w.t, c) }
                    })
                }
            }
            events.text = all.takeLast(30).reversed().joinToString("\n") { "${Diag.time(it.t)} ${it.kind}${if (it.value != 0L && it.kind != "session-lost") " (${it.value})" else ""} ${it.text}" }
            main.postDelayed(this, 1000)
        }
    }

    private fun routeVerdict(): String {
        if (!Diag.serviceRunning) return ""
        val micOk = Diag.micRoute.startsWith("phone microphone")
        val playA2dp = Diag.playbackRoute.contains("A2DP")
        val call = Diag.scoOn || Diag.audioMode.contains("COMMUNICATION") || Diag.playbackRoute.contains("SCO")
        return when {
            call -> "⚠ CALL-QUALITY AUDIO detected: Bluetooth switched to call mode\n"
            micOk && playA2dp -> "✓ Phone mic listening, earbuds playing in music quality\n"
            !playA2dp -> "• Playback is not on Bluetooth A2DP (are the earbuds connected?)\n"
            else -> "• Microphone is not the phone mic: check the route above\n"
        }
    }

    // ---------- actions ----------

    private fun askPermissions() {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(needed.toTypedArray(), 1)
    }

    private fun batteryExempt(): Boolean = (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    private fun askBatteryExemption() {
        if (batteryExempt()) { toast("Already allowed to run in the background."); return }
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun makeTestEpisode() {
        toast("Preparing the test episode with the phone's voice…")
        Thread {
            val err = TestEpisode.generate(this) { done, total -> runOnUiThread { sourceLabel.text = "Preparing test episode: $done of $total parts…" } }
            runOnUiThread {
                if (err == null) {
                    prefs.edit().putString("source", Uri.fromFile(TestEpisode.file(this)).toString()).apply()
                    toast("Test episode ready.")
                } else toast(err)
                updateSourceLabel()
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 42 && resultCode == RESULT_OK && uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString("source", uri.toString()).apply()
            updateSourceLabel()
        }
    }

    private fun updateSourceLabel() {
        val s = prefs.getString("source", null)
        sourceLabel.text = when {
            s == null -> "Nothing chosen yet."
            s.startsWith("file:") -> "Using: test episode (Sada's 6 episodes, phone voice, loops)"
            else -> "Using: your audio file (loops)"
        }
    }

    private fun toggle() {
        if (Diag.serviceRunning) {
            startService(Intent(this, SadaService::class.java).setAction(SadaService.ACTION_STOP))
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Allow the microphone first (step 1)."); askPermissions(); return
        }
        val playback = prefs.getBoolean("playback", true)
        val source = prefs.getString("source", null)
        if (playback && source == null) { toast("Choose what to listen to first (step 2), or untick “Play the podcast”."); return }
        prefs.edit().putString("attempts", attempts.text.toString()).apply()
        val i = Intent(this, SadaService::class.java)
            .setAction(SadaService.ACTION_START)
            .putExtra(SadaService.EXTRA_SOURCE, source)
            .putExtra(SadaService.EXTRA_SENSITIVITY, prefs.getString("sens", "default"))
            .putExtra(SadaService.EXTRA_MIC_MODE, prefs.getString("mic", "recognition"))
            .putExtra(SadaService.EXTRA_PLAYBACK, playback)
        // Must start while this screen is visible: Android only grants background microphone use this way.
        startForegroundService(i)
    }

    private fun runSelfTest() {
        if (selfTestRunning) return
        selfTestRunning = true
        selfTestView.text = "Running…"
        Thread {
            val result = try { SelfTest.run(this) { p -> runOnUiThread { selfTestView.text = p + "\n…" } } }
                catch (e: Throwable) { "Self-test crashed: ${e.javaClass.simpleName}: ${e.message}" }
            runOnUiThread { selfTestView.text = result; selfTestRunning = false }
        }.start()
    }

    private fun mark() {
        if (!Diag.serviceRunning) { toast("Start the test first."); return }
        startService(Intent(this, SadaService::class.java).setAction(SadaService.ACTION_MARK_MISS))
    }

    private fun copyReport() {
        prefs.edit().putString("attempts", attempts.text.toString()).apply()
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Sada Stage 0 report", Diag.report(attempts.text.toString().toIntOrNull())))
        toast("Report copied. Paste it into your chat with Claude.")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
