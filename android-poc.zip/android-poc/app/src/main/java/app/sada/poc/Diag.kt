package app.sada.poc

import android.content.Context
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One diagnostics event. value carries a number where useful (e.g. a delay in ms). */
data class DiagEvent(val t: Long, val kind: String, val value: Long, val text: String)

/**
 * Diagnostics shared by the service and the screen. Events are also written to a file, so results
 * survive if Android kills the app during a locked-screen test. Nothing here leaves the phone.
 */
object Diag {
    private val lock = Any()
    private val events = ArrayList<DiagEvent>()
    private val falseMarks = HashSet<Long>()
    private var eventsFile: File? = null
    private var marksFile: File? = null
    private var ready = false

    // Live values written by the service, read by the screen.
    @Volatile var phase: String = "STOPPED"
    @Volatile var serviceRunning = false
    @Volatile var startedAt = 0L
    @Volatile var micRoute = "-"
    @Volatile var playbackRoute = "-"
    @Volatile var audioMode = "-"
    @Volatile var scoOn = false
    @Volatile var micLevelDb = -99.0
    @Volatile var micLevelAvgDb = -99.0
    @Volatile var micSilenced = false
    @Volatile var kwsChunkMsAvg = 0.0
    @Volatile var kwsChunkMsMax = 0.0
    @Volatile var screenOn = true
    @Volatile var batteryPct = -1
    @Volatile var batteryAtStart = -1
    @Volatile var ignoringBatteryOpt = false
    @Volatile var standbyBucket = "-"
    @Volatile var bgRestricted = false
    @Volatile var lastHeartbeat = 0L
    @Volatile var source = "-"
    @Volatile var keywordsMode = "built-in thresholds"
    @Volatile var testMode = "walking"
    @Volatile var playback = true

    // Audio-to-keyword pipeline (what actually reaches the detector)
    @Volatile var micSource = "-"
    @Volatile var micFormat = "-"
    @Volatile var samplesFed = 0L
    @Volatile var buffersFed = 0L
    @Volatile var emptyReads = 0L
    @Volatile var lastReadCode = 0
    @Volatile var zeroBuffers = 0L
    @Volatile var clippedSamples = 0L
    @Volatile var micPeak = 0.0
    @Volatile var modelStatus = "not loaded yet"
    @Volatile var keywordCheck = "not checked yet"
    @Volatile var probeStatus = "-"
    @Volatile var selfTest = "not run yet"

    fun resetInputCounters() {
        samplesFed = 0; buffersFed = 0; emptyReads = 0; lastReadCode = 0; zeroBuffers = 0; clippedSamples = 0; micPeak = 0.0
    }

    fun init(ctx: Context) {
        synchronized(lock) {
            if (ready) return
            ready = true
            eventsFile = File(ctx.filesDir, "events.tsv")
            marksFile = File(ctx.filesDir, "false-marks.txt")
            eventsFile?.let { f ->
                if (f.exists()) f.forEachLine { line ->
                    val p = line.split('\t', limit = 4)
                    if (p.size == 4) {
                        val t = p[0].toLongOrNull()
                        val v = p[2].toLongOrNull()
                        if (t != null && v != null) events.add(DiagEvent(t, p[1], v, p[3]))
                    }
                }
            }
            marksFile?.let { f -> if (f.exists()) f.forEachLine { l -> l.trim().toLongOrNull()?.let { falseMarks.add(it) } } }
        }
    }

    /**
     * If the last test's heartbeat says "running" but no service is running in this process,
     * Android stopped it. Logs that once (value = time of the last heartbeat).
     */
    fun checkLostSession(ctx: Context) {
        if (serviceRunning) return
        val f = File(ctx.filesDir, "heartbeat.txt")
        if (!f.exists()) return
        val p = try { f.readText().split('\t') } catch (_: Exception) { return }
        if (p.size >= 3 && p[0] == "running") {
            val last = p[1].toLongOrNull() ?: return
            val began = p[2].toLongOrNull() ?: last
            log("session-lost", "The previous test was stopped by Android at about ${time(last)} after ${(last - began) / 60000} min (not by you)", last)
            try { f.writeText("lost\t$last\t$began") } catch (_: Exception) {}
        }
    }

    fun log(kind: String, text: String, value: Long = 0L): DiagEvent {
        val e = DiagEvent(System.currentTimeMillis(), kind, value, text.replace('\t', ' ').replace('\n', ' '))
        synchronized(lock) {
            events.add(e)
            if (events.size > 3000) events.removeAt(0)
            try { eventsFile?.appendText("${e.t}\t${e.kind}\t${e.value}\t${e.text}\n") } catch (_: Exception) {}
        }
        return e
    }

    fun snapshot(): List<DiagEvent> = synchronized(lock) { ArrayList(events) }

    fun isFalse(t: Long): Boolean = synchronized(lock) { falseMarks.contains(t) }

    fun setFalse(t: Long, isFalse: Boolean) {
        synchronized(lock) {
            if (isFalse) falseMarks.add(t) else falseMarks.remove(t)
            try { marksFile?.writeText(falseMarks.joinToString("\n")) } catch (_: Exception) {}
        }
    }

    fun reset() {
        synchronized(lock) {
            events.clear()
            falseMarks.clear()
            try { eventsFile?.delete(); marksFile?.delete() } catch (_: Exception) {}
        }
        log("reset", "Results cleared")
    }

    // ---- statistics ----

    data class Stats(
        val wakes: Int,
        val wakesMarkedFalse: Int,
        val continues: Int,
        val continueWhilePlaying: Int,
        val missedWake: Int,
        val missedContinue: Int,
        val pauseMs: List<Long>,
        val answerMs: List<Long>,
        val resumeMs: List<Long>,
        val driftMs: List<Long>,
        val unexpectedStops: Int,
        val listeningMinutes: Double,
        val rawDetections: Int,
        val nearMisses: Int,
        val ignored: Int,
    )

    fun stats(): Stats {
        val ev = snapshot()
        val wakes = ev.filter { it.kind == "wake" }
        var listening = 0L
        var openAt = -1L
        for (e in ev) {
            when (e.kind) {
                "session-start" -> openAt = e.t
                "session-stop", "session-lost" -> { if (openAt > 0) listening += (if (e.kind == "session-lost") e.value else e.t) - openAt; openAt = -1 }
            }
        }
        if (openAt > 0 && serviceRunning) listening += System.currentTimeMillis() - openAt
        return Stats(
            wakes = wakes.size,
            wakesMarkedFalse = wakes.count { isFalse(it.t) },
            continues = ev.count { it.kind == "continue" },
            continueWhilePlaying = ev.count { it.kind == "continue-while-playing" },
            missedWake = ev.count { it.kind == "miss-wake" },
            missedContinue = ev.count { it.kind == "miss-continue" },
            pauseMs = wakes.map { it.value },
            answerMs = ev.filter { it.kind == "answer-start" }.map { it.value },
            resumeMs = ev.filter { it.kind == "continue" }.map { it.value },
            driftMs = ev.filter { it.kind == "resume-drift" }.map { it.value },
            unexpectedStops = ev.count { it.kind == "session-lost" },
            listeningMinutes = listening / 60000.0,
            rawDetections = ev.count { it.kind == "kws-raw" },
            nearMisses = ev.count { it.kind == "near-miss" },
            ignored = ev.count { it.kind == "ignored" },
        )
    }

    fun summarize(xs: List<Long>): String {
        if (xs.isEmpty()) return "-"
        val s = xs.sorted()
        return "median ${s[s.size / 2]} ms, max ${s.last()} ms (n=${s.size})"
    }

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    fun time(t: Long): String = timeFmt.format(Date(t))

    fun report(attempts: Int?): String {
        val st = stats()
        val sb = StringBuilder()
        sb.append("Sada Stage 0 report — ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())}\n")
        sb.append("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        sb.append("Test mode: $testMode | playback: ${if (playback) "on" else "OFF (listen only)"} | keywords: $keywordsMode | source: $source\n\n")
        sb.append("Model: $modelStatus\nKeywords: $keywordCheck\nNear-miss listener: $probeStatus\n")
        sb.append("Mic input: $micSource; $micFormat\n")
        sb.append("Reached detector: $samplesFed samples in $buffersFed buffers (${"%.1f".format(samplesFed / 16000.0)} s) | empty reads: $emptyReads (last code $lastReadCode) | all-zero buffers: $zeroBuffers | clipped samples: $clippedSamples | peak ${"%.2f".format(micPeak)}\n")
        sb.append("Raw detector outputs: ${st.rawDetections} | near misses: ${st.nearMisses} | ignored before start/while speaking: ${st.ignored}\n")
        sb.append("Self-test: $selfTest\n\n")
        sb.append("Listening time: ${"%.1f".format(st.listeningMinutes)} min | unexpected stops: ${st.unexpectedStops}\n")
        sb.append("Wake detections: ${st.wakes} (marked false: ${st.wakesMarkedFalse})\n")
        if (attempts != null && attempts > 0) {
            val hits = (st.wakes - st.wakesMarkedFalse).coerceAtLeast(0)
            sb.append("Hey Sada attempts (you entered): $attempts → detected ${hits} (${100 * hits / attempts}%), missed ${(attempts - hits).coerceAtLeast(0)}\n")
        }
        sb.append("Missed wake (earbud taps): ${st.missedWake} | missed Continue (earbud taps): ${st.missedContinue}\n")
        sb.append("Continue detections: ${st.continues} | 'Continue' heard while playing (false): ${st.continueWhilePlaying}\n")
        val perHour = if (st.listeningMinutes > 0) (st.wakesMarkedFalse + st.continueWhilePlaying) * 60.0 / st.listeningMinutes else 0.0
        sb.append("False activations per hour: ${"%.1f".format(perHour)}\n\n")
        sb.append("Wake → paused: ${summarize(st.pauseMs)}\n")
        sb.append("Wake → response starts: ${summarize(st.answerMs)}\n")
        sb.append("Continue → playing: ${summarize(st.resumeMs)}\n")
        sb.append("Resume position error: ${summarize(st.driftMs.map { kotlin.math.abs(it) })}\n\n")
        sb.append("Microphone: $micRoute\nPlayback: $playbackRoute\nAudio mode: $audioMode | Bluetooth call audio (SCO): ${if (scoOn) "ON" else "off"}\n")
        sb.append("Mic level now/avg: ${"%.0f".format(micLevelDb)} / ${"%.0f".format(micLevelAvgDb)} dBFS | silenced by system: $micSilenced\n")
        sb.append("Keyword engine per 100 ms of audio: avg ${"%.1f".format(kwsChunkMsAvg)} ms, max ${"%.0f".format(kwsChunkMsMax)} ms\n")
        sb.append("Battery: start $batteryAtStart% now $batteryPct% | ignoring battery optimization: $ignoringBatteryOpt | standby bucket: $standbyBucket | background restricted: $bgRestricted\n\n")
        sb.append("Last events:\n")
        snapshot().takeLast(60).forEach { e ->
            sb.append("${time(e.t)} ${e.kind}${if (e.value != 0L) " (${e.value})" else ""} ${e.text}${if (isFalse(e.t)) " [marked false]" else ""}\n")
        }
        return sb.toString()
    }
}
