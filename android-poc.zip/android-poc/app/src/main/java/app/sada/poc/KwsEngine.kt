package app.sada.poc

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.SystemClock
import com.k2fsa.sherpa.onnx.KeywordSpotter
import com.k2fsa.sherpa.onnx.KeywordSpotterConfig
import com.k2fsa.sherpa.onnx.OnlineStream
import com.k2fsa.sherpa.onnx.getFeatureConfig
import com.k2fsa.sherpa.onnx.getKwsModelConfig
import kotlin.math.max
import kotlin.math.min

const val MODEL_DIR = "sherpa-onnx-kws-zipformer-gigaspeech-3.3M-2024-01-01"
const val SAMPLE_RATE = 16000

/** Creates keyword spotters from the bundled model. Shared by the live engine and the self-test. */
object Kws {
    fun spotter(ctx: Context, keywordsAsset: String): KeywordSpotter {
        val config = KeywordSpotterConfig(
            featConfig = getFeatureConfig(SAMPLE_RATE, 80),
            modelConfig = getKwsModelConfig(1)!!, // 1 = English GigaSpeech model (checked in CI)
            keywordsFile = keywordsAsset,
        )
        return KeywordSpotter(ctx.assets, config)
    }

    /**
     * Feeds 16 kHz float samples to a stream and returns every keyword the spotter reports.
     * The live microphone and the self-test both go through this function.
     */
    fun feed(spotter: KeywordSpotter, stream: OnlineStream, samples: FloatArray): List<String> {
        stream.acceptWaveform(samples, SAMPLE_RATE)
        while (spotter.isReady(stream)) spotter.decode(stream)
        val k = spotter.getResult(stream).keyword
        if (k.isBlank()) return emptyList()
        spotter.reset(stream)
        return listOf(k.trim())
    }

    /** Feeds a whole recording in 100 ms pieces with silence before and after, like live audio. */
    fun feedRecording(spotter: KeywordSpotter, stream: OnlineStream, audio: FloatArray): List<String> {
        val out = ArrayList<String>()
        val padded = FloatArray(SAMPLE_RATE / 2) + audio + FloatArray(SAMPLE_RATE)
        var i = 0
        while (i < padded.size) {
            val end = min(padded.size, i + SAMPLE_RATE / 10)
            out.addAll(feed(spotter, stream, padded.copyOfRange(i, end)))
            i = end
        }
        return out
    }

    fun readAssetLines(ctx: Context, path: String): List<String> =
        ctx.assets.open(path).bufferedReader().readLines()

    /** Checks the bundled keywords against the model's vocabulary and records the result. */
    fun checkKeywords(ctx: Context): Boolean {
        return try {
            val kw = readAssetLines(ctx, "$MODEL_DIR/keywords.txt").filter { it.isNotBlank() }
            val vocab = KeywordFile.vocabulary(readAssetLines(ctx, "$MODEL_DIR/tokens.txt"))
            val issues = KeywordFile.validate(kw, vocab, listOf("HEY_SADA", "CONTINUE"))
            val list = kw.mapNotNull { KeywordFile.parseLine(it) }.joinToString("; ") {
                "${it.label}: ${it.tokens.joinToString(" ")} (boost ${it.score ?: "default"}, threshold ${it.threshold ?: "default"})"
            }
            Diag.keywordCheck = if (issues.isEmpty()) "✓ ${kw.size} keywords valid for the model: $list" else "✗ ${issues.joinToString("; ")}"
            Diag.log(if (issues.isEmpty()) "keywords" else "error", Diag.keywordCheck)
            issues.isEmpty()
        } catch (e: Exception) {
            Diag.keywordCheck = "✗ could not read keyword files: ${e.message}"
            Diag.log("error", Diag.keywordCheck)
            false
        }
    }
}

/**
 * Continuous, offline keyword spotting on the phone's built-in microphone.
 * Audio never leaves the phone (the app has no internet permission) and is never saved.
 */
class KwsEngine(private val ctx: Context, private val onKeyword: (label: String, atMs: Long) -> Unit) {
    @Volatile private var running = false
    @Volatile var muted = false          // true while Sada speaks: results are ignored
    @Volatile private var flush = false  // drop buffered audio/state after Sada has spoken
    private var thread: Thread? = null
    private var record: AudioRecord? = null
    private var kws: KeywordSpotter? = null
    private var stream: OnlineStream? = null
    private var probe: OnlineStream? = null   // diagnostic only: very low thresholds, never acts

    /**
     * sensitivity: "default" uses the thresholds in keywords.txt; others adjust them (experimental).
     * micMode: "recognition" (Android's speech-recognition input) or "plain" (unprocessed microphone).
     */
    fun start(sensitivity: String, micMode: String): Boolean {
        if (running) return true
        Kws.checkKeywords(ctx)
        try {
            if (kws == null) kws = Kws.spotter(ctx, "$MODEL_DIR/keywords.txt")
            val custom = customKeywords(sensitivity)
            stream = if (custom == null) kws!!.createStream() else kws!!.createStream(custom)
            Diag.keywordsMode = if (custom == null) "built-in thresholds" else "sensitivity: $sensitivity (experimental)"
            Diag.modelStatus = "✓ model loaded ($MODEL_DIR)"
            Diag.log("model", Diag.modelStatus)
        } catch (e: Throwable) {
            Diag.modelStatus = "✗ model failed to load: ${e.javaClass.simpleName}: ${e.message}"
            Diag.log("error", Diag.modelStatus)
            return false
        }
        probe = try {
            val lines = Kws.readAssetLines(ctx, "$MODEL_DIR/keywords.txt")
            kws!!.createStream(KeywordFile.withThreshold(lines, 0.08).joinToString("/")).also {
                Diag.probeStatus = "on (threshold 0.08, logs only)"
            }
        } catch (e: Throwable) {
            Diag.probeStatus = "unavailable: ${e.javaClass.simpleName}"
            null
        }

        val source = if (micMode == "plain") MediaRecorder.AudioSource.MIC else MediaRecorder.AudioSource.VOICE_RECOGNITION
        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufBytes = max(minBuf, SAMPLE_RATE * 2)
        val rec = try {
            // Neither source puts Bluetooth into call (SCO) mode.
            AudioRecord(source, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufBytes)
        } catch (e: SecurityException) {
            Diag.log("error", "Microphone permission missing")
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            Diag.log("error", "Microphone could not be opened (another app may be using it)")
            rec.release()
            return false
        }
        val builtIn = builtInMic()
        if (builtIn != null) {
            val ok = rec.setPreferredDevice(builtIn)
            Diag.log("route", "Asked Android to use the ${AudioNames.describe(builtIn)}: ${if (ok) "accepted" else "refused"}")
        } else {
            Diag.log("route", "No built-in microphone listed by Android")
        }
        rec.startRecording()
        if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            Diag.log("error", "Microphone did not start recording (state ${rec.recordingState})")
            rec.release()
            return false
        }
        record = rec
        // What Android actually delivers, not what was requested.
        Diag.micSource = if (micMode == "plain") "plain microphone (MIC)" else "speech recognition (VOICE_RECOGNITION)"
        Diag.micFormat = "${rec.sampleRate} Hz, ${rec.channelCount} channel(s), ${encodingName(rec.audioFormat)}, buffer $bufBytes bytes (min $minBuf)"
        Diag.log("mic", "Input: ${Diag.micSource}; ${Diag.micFormat}")
        if (rec.sampleRate != SAMPLE_RATE || rec.channelCount != 1 || rec.audioFormat != AudioFormat.ENCODING_PCM_16BIT) {
            Diag.log("error", "Microphone format differs from what the model needs (16000 Hz, mono, 16-bit)")
        }
        Diag.resetInputCounters()
        updateRoute()
        running = true
        thread = Thread({ loop(rec) }, "sada-kws").also { it.start() }
        return true
    }

    fun stop() {
        running = false
        try { thread?.join(1500) } catch (_: InterruptedException) {}
        thread = null
        try { record?.stop() } catch (_: Exception) {}
        record?.release()
        record = null
        stream = null
        probe = null
    }

    /** Called after Sada finishes speaking, so audio heard during the answer can't trigger anything. */
    fun flushAfterSpeaking() { flush = true }

    fun updateRoute() {
        val r = record ?: return
        Diag.micRoute = AudioNames.describe(r.routedDevice)
    }

    private fun builtInMic(): AudioDeviceInfo? {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
    }

    private fun encodingName(e: Int) = when (e) {
        AudioFormat.ENCODING_PCM_16BIT -> "PCM 16-bit"
        AudioFormat.ENCODING_PCM_FLOAT -> "PCM float"
        AudioFormat.ENCODING_PCM_8BIT -> "PCM 8-bit"
        else -> "encoding $e"
    }

    private fun loop(rec: AudioRecord) {
        val buf = ShortArray(SAMPLE_RATE / 10) // 100 ms
        var chunks = 0L
        var totalMs = 0.0
        var maxMs = 0.0
        var levelSum = 0.0
        var levelN = 0
        var lastProbe = 0L
        var lastMain = 0L
        while (running) {
            val n = rec.read(buf, 0, buf.size)
            if (n <= 0) {
                Diag.emptyReads++
                Diag.lastReadCode = n
                SystemClock.sleep(20)
                continue
            }
            val st = Pcm.stats(buf, n)
            Diag.micLevelDb = st.rmsDb
            Diag.micPeak = max(Diag.micPeak * 0.98, st.peak)
            Diag.clippedSamples += st.clipped
            if (st.zeros == n) Diag.zeroBuffers++
            levelSum += st.rmsDb; levelN++
            if (levelN >= 50) { Diag.micLevelAvgDb = levelSum / levelN; levelSum = 0.0; levelN = 0 }

            val spotter = kws ?: continue
            val s = stream ?: continue
            if (flush) { spotter.reset(s); probe?.let { spotter.reset(it) }; flush = false }
            val samples = Pcm.toFloat(buf, n)
            val t0 = SystemClock.elapsedRealtimeNanos()
            val hits = Kws.feed(spotter, s, samples)
            // The near-miss stream sees the same samples; its results are only logged.
            val probeHits = probe?.let { p -> try { Kws.feed(spotter, p, samples) } catch (_: Throwable) { emptyList() } } ?: emptyList()
            val ms = (SystemClock.elapsedRealtimeNanos() - t0) / 1e6
            Diag.samplesFed += n
            Diag.buffersFed++
            chunks++; totalMs += ms; if (ms > maxMs) maxMs = ms
            if (chunks % 20 == 0L) { Diag.kwsChunkMsAvg = totalMs / chunks; Diag.kwsChunkMsMax = maxMs }
            val now = System.currentTimeMillis()
            for (k in hits) {
                lastMain = now
                Diag.log("kws-raw", "Detector reported $k${if (muted) " (ignored: Sada speaking)" else ""}")
                if (!muted) onKeyword(k, now)
            }
            for (k in probeHits) {
                // Only interesting if the real detector did not fire around the same time.
                if (now - lastMain > 1500 && now - lastProbe > 1500) Diag.log("near-miss", "Almost detected $k (below the real threshold)")
                lastProbe = now
            }
        }
    }

    /** Builds a keywords string with adjusted trigger thresholds from the bundled keywords.txt. */
    private fun customKeywords(sensitivity: String): String? {
        if (sensitivity == "default") return null
        val delta = if (sensitivity == "more") -0.08 else 0.08
        val lines = Kws.readAssetLines(ctx, "$MODEL_DIR/keywords.txt").filter { it.isNotBlank() }
        return lines.joinToString("/") { line ->
            val m = Regex("#([0-9.]+)").find(line)
            if (m != null) {
                val v = (m.groupValues[1].toDouble() + delta).coerceIn(0.05, 0.9)
                line.replace(m.value, "#" + String.format(java.util.Locale.US, "%.2f", v))
            } else line
        }
    }
}
