package app.sada.poc

import android.content.Context
import android.media.AudioAttributes
import app.sada.poc.dsp.FrontEnd
import app.sada.poc.dsp.InputGain
import app.sada.poc.dsp.SignalClassifier
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Consented 10-second microphone check. Records the raw phone microphone and exactly what the detector received,
 * stores both only in the app's private storage (the app has no internet permission), and analyses them:
 * signal type per second, levels, and whether a fresh detector finds "Hey Sada" in the recording as received and at
 * several fixed gains. Never written to logs; deletable at any time; removed automatically after 24 hours.
 */
object MicCheck {
    const val SECONDS = 10

    fun dir(ctx: Context) = File(ctx.filesDir, "mic-checks").also { it.mkdirs() }

    class Recorder {
        val raw = FloatArray(SAMPLE_RATE * SECONDS)
        val det = FloatArray(SAMPLE_RATE * SECONDS)
        private var pos = 0
        /** Adds one block of each; returns true when full. */
        fun add(r: FloatArray, d: FloatArray): Boolean {
            val n = minOf(r.size, raw.size - pos)
            System.arraycopy(r, 0, raw, pos, n)
            System.arraycopy(d, 0, det, pos, n)
            pos += n
            return pos >= raw.size
        }
    }

    private fun toPcm(x: FloatArray) = ShortArray(x.size) { (x[it] * 32767f).toInt().coerceIn(-32768, 32767).toShort() }

    fun save(ctx: Context, r: Recorder): String {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        File(dir(ctx), "$stamp-raw.wav").writeBytes(Wav.encodeMono16(toPcm(r.raw), SAMPLE_RATE))
        File(dir(ctx), "$stamp-detector.wav").writeBytes(Wav.encodeMono16(toPcm(r.det), SAMPLE_RATE))
        return stamp
    }

    /** Worker thread. Returns a human-readable result (no audio content). */
    fun analyse(ctx: Context, r: Recorder): String {
        val sb = StringBuilder()
        // signal per second
        val c = SignalClassifier(FrontEnd.BLOCK, SAMPLE_RATE)
        val kinds = ArrayList<String>()
        val blk = FloatArray(FrontEnd.BLOCK)
        var i = 0
        while (i + FrontEnd.BLOCK <= r.raw.size) {
            System.arraycopy(r.raw, i, blk, 0, FrontEnd.BLOCK)
            c.process(blk, FrontEnd.BLOCK)?.let { kinds.add(it.name.lowercase().replace('_', ' ')) }
            i += FrontEnd.BLOCK
        }
        var peak = 0f
        var sum = 0.0
        for (v in r.raw) { peak = maxOf(peak, kotlin.math.abs(v)); sum += v * v }
        val rawDb = 10 * kotlin.math.log10(sum / r.raw.size + 1e-14)
        sb.append("raw level ${"%.0f".format(rawDb)} dBFS, peak ${"%.2f".format(peak)}; seconds: ${kinds.joinToString(", ")}. ")
        // does a fresh detector find the keywords in this audio?
        try {
            val sp = Kws.spotter(ctx, "$MODEL_DIR/keywords.txt")
            fun run(x: FloatArray): String {
                val hits = Kws.feedRecording(sp, sp.createStream(), x)
                return if (hits.isEmpty()) "nothing" else hits.joinToString("+")
            }
            sb.append("Fresh detector: as received → ${run(r.det)}")
            for (g in listOf(0.0, 10.0, 20.0, 30.0)) {
                val ig = InputGain().also { it.setGainDb(g) }
                val y = FloatArray(r.raw.size)
                ig.process(r.raw, y, r.raw.size)
                sb.append("; raw +${g.toInt()} dB → ${run(y)}")
            }
            sb.append(".")
        } catch (e: Throwable) {
            sb.append("Detector check failed: ${e.javaClass.simpleName}.")
        }
        return sb.toString()
    }

    fun latest(ctx: Context): File? = dir(ctx).listFiles { f -> f.name.endsWith("-raw.wav") }?.maxByOrNull { it.name }

    fun play(ctx: Context, f: File, attrs: AudioAttributes) {
        val a = Wav.decode(f.readBytes()) ?: return
        Replay.play(a.samples, attrs)
    }

    fun deleteAll(ctx: Context): Int {
        val files = dir(ctx).listFiles() ?: return 0
        files.forEach { it.delete() }
        return files.size
    }

    fun deleteOlderThanHours(ctx: Context, hours: Int) {
        val cutoff = System.currentTimeMillis() - hours * 3600_000L
        dir(ctx).listFiles()?.filter { it.lastModified() < cutoff }?.forEach { it.delete() }
    }
}
