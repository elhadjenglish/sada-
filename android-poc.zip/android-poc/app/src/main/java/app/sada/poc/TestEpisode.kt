package app.sada.poc

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Renders Sada's six original episodes with the phone's voice into one WAV file (about 15 minutes, played on loop). */
object TestEpisode {
    fun file(ctx: Context) = File(ctx.filesDir, "test-episode.wav")

    /** Runs on a background thread. progress(done, total); returns null on success or an error message. */
    fun generate(ctx: Context, progress: (Int, Int) -> Unit): String? {
        val ready = CountDownLatch(1)
        var ok = false
        lateinit var tts: TextToSpeech
        tts = TextToSpeech(ctx.applicationContext) { status -> ok = status == TextToSpeech.SUCCESS; ready.countDown() }
        if (!ready.await(15, TimeUnit.SECONDS) || !ok) return "The phone's text-to-speech engine did not start."
        tts.setLanguage(Locale.US)
        val parts = ArrayList<File>()
        try {
            for ((i, text) in EPISODE_TEXTS.withIndex()) {
                progress(i, EPISODE_TEXTS.size)
                val out = File(ctx.cacheDir, "ep$i.wav")
                val done = CountDownLatch(1)
                var failed = false
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { done.countDown() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { failed = true; done.countDown() }
                })
                val r = tts.synthesizeToFile(text, Bundle(), out, "ep$i")
                if (r != TextToSpeech.SUCCESS) return "The phone's voice could not render episode ${i + 1}."
                if (!done.await(180, TimeUnit.SECONDS) || failed || !out.exists()) return "Rendering episode ${i + 1} failed or timed out."
                parts.add(out)
            }
            progress(EPISODE_TEXTS.size, EPISODE_TEXTS.size)
            return Wav.concat(parts, file(ctx), silenceSeconds = 1.5)
        } finally {
            tts.shutdown()
            parts.forEach { it.delete() }
        }
    }
}
