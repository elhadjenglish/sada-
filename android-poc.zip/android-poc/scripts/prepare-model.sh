#!/usr/bin/env bash
# Downloads the English keyword-spotting model and converts Sada's phrases into model tokens.
set -euo pipefail
: "${KWS_MODEL:?set KWS_MODEL}"
WORK="${RUNNER_TEMP:-/tmp}/kws"
rm -rf "$WORK"; mkdir -p "$WORK"
curl -fsSL -o "$WORK/model.tar.bz2" "https://github.com/k2-fsa/sherpa-onnx/releases/download/kws-models/${KWS_MODEL}.tar.bz2"
tar xjf "$WORK/model.tar.bz2" -C "$WORK"
M="$WORK/$KWS_MODEL"
ls -la "$M"

python3 -m pip install --quiet "sherpa-onnx==${SHERPA_VERSION}" sentencepiece numpy || python3 -m pip install --quiet sherpa-onnx sentencepiece numpy
sherpa-onnx-cli text2token --tokens "$M/tokens.txt" --tokens-type bpe --bpe-model "$M/bpe.model" keywords/keywords-input.txt "$WORK/keywords.txt"
echo "-- keywords.txt (tokens):"; cat "$WORK/keywords.txt"
[ -s "$WORK/keywords.txt" ] || { echo "::error::keyword conversion produced nothing"; exit 1; }

A="app/src/main/assets/$KWS_MODEL"
rm -rf app/src/main/assets; mkdir -p "$A"
cp "$M"/*.onnx "$M/tokens.txt" "$A"/
cp "$WORK/keywords.txt" "$A/keywords.txt"   # replaces the model's sample keywords
ls -la "$A"
echo "MODEL_DIR=$M" >> "${GITHUB_ENV:-/dev/null}"
echo "KEYWORDS_FILE=$WORK/keywords.txt" >> "${GITHUB_ENV:-/dev/null}"
